(function () {



/* Exports */
Package._define("kosst:css-star-rating");

})();
