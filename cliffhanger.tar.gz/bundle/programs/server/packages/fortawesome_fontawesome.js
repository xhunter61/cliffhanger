(function () {



/* Exports */
Package._define("fortawesome:fontawesome");

})();
