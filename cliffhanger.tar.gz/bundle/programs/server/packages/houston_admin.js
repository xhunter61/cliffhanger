(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Accounts = Package['accounts-base'].Accounts;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/houston_admin/lib/collections.coffee.js                                                            //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var root;

root = typeof exports !== "undefined" && exports !== null ? exports : this;

if (root.Houston == null) {
  root.Houston = {};
}

if (Houston._collections == null) {
  Houston._collections = {};
}

Houston._collections.collections = new Meteor.Collection('houston_collections');

Houston._admins = new Meteor.Collection('houston_admins');

Houston._user_is_admin = function(id) {
  return (id != null) && Houston._admins.findOne({
    user_id: id
  });
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/houston_admin/lib/shared.coffee.js                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var root;

root = typeof exports !== "undefined" && exports !== null ? exports : this;

if (root.Houston == null) {
  root.Houston = {};
}

Houston._houstonize = function(name) {
  return "_houston_" + name;
};

Houston._custom_method_name = function(collection_name, method_name) {
  return Houston._houstonize(collection_name + "/" + method_name);
};

Houston._MAX_DOCS_TO_EXPLORE = 100;

Houston._get_fields_from_collection = function(collection) {
  return Houston._get_fields(collection.find().fetch());
};

Houston._get_fields = function(documents, options) {
  var document, find_fields, i, key, key_to_type, len, ref, results, value;
  if (options == null) {
    options = {};
  }
  key_to_type = options.exclude_id != null ? {} : {
    _id: 'ObjectId'
  };
  find_fields = function(document, prefix) {
    var full_path_key, key, ref, results, value;
    if (prefix == null) {
      prefix = '';
    }
    ref = _.omit(document, '_id');
    results = [];
    for (key in ref) {
      value = ref[key];
      if (typeof value === 'object') {
        if (value instanceof Date) {
          full_path_key = "" + prefix + key;
          results.push(key_to_type[full_path_key] = "Date");
        } else {
          results.push(find_fields(value, "" + prefix + key + "."));
        }
      } else if (typeof value !== 'function') {
        full_path_key = "" + prefix + key;
        results.push(key_to_type[full_path_key] = typeof value);
      } else {
        results.push(void 0);
      }
    }
    return results;
  };
  ref = documents.slice(0, +Houston._MAX_DOCS_TO_EXPLORE + 1 || 9e9);
  for (i = 0, len = ref.length; i < len; i++) {
    document = ref[i];
    find_fields(document);
  }
  results = [];
  for (key in key_to_type) {
    value = key_to_type[key];
    results.push({
      name: key,
      type: value
    });
  }
  return results;
};

Houston._get_field_names = function(documents) {
  return _.pluck(Houston._get_fields(documents), 'name');
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/houston_admin/lib/menu.coffee.js                                                                   //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var root;

root = typeof exports !== "undefined" && exports !== null ? exports : this;

if (root.Houston == null) {
  root.Houston = {};
}

Houston.menu = function() {
  var i, item, len;
  for (i = 0, len = arguments.length; i < len; i++) {
    item = arguments[i];
    this.menu._add_menu_item(item);
  }
};

Houston.menu.dependency = new Deps.Dependency;

Houston.menu._menu_items = [];

Houston.menu._process_item = function(item) {
  if (item.type !== 'link' && item.type !== 'template') {
    throw new Meteor.Error(400, 'Can\'t recognize type: ' + item);
  }
  if (item.type === 'link') {
    item.path = item.use;
  } else if (item.type === 'template') {
    item.path = Houston._ROOT_ROUTE + "/actions/" + item.use;
  }
  return item;
};

Houston.menu._get_menu_items = function() {
  var i, item, len, ref, results;
  this.dependency.depend();
  ref = this._menu_items;
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    item = ref[i];
    results.push(this._process_item(item));
  }
  return results;
};

Houston.menu._add_menu_item = function(item) {
  this._menu_items.push(item);
  return this.dependency.changed();
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/houston_admin/server/publications.coffee.js                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ADDED_COLLECTIONS, root, sync_collections;

root = typeof exports !== "undefined" && exports !== null ? exports : this;

Houston._HIDDEN_COLLECTIONS = {
  'users': Meteor.users,
  'meteor_accounts_loginServiceConfiguration': void 0
};

ADDED_COLLECTIONS = {};

Houston._publish = function(name, func) {
  return Meteor.publish(Houston._houstonize(name), func);
};

Houston._setup_collection = function(collection) {
  var c, count, fields, name;
  name = collection._name;
  if (name in ADDED_COLLECTIONS) {
    return;
  }
  Houston._setup_collection_methods(collection);
  Houston._publish(name, function(sort, filter, limit, unknown_arg) {
    var e;
    check(sort, Match.Optional(Object));
    check(filter, Match.Optional(Object));
    check(limit, Match.Optional(Number));
    check(unknown_arg, Match.Any);
    if (!Houston._user_is_admin(this.userId)) {
      this.ready();
      return;
    }
    try {
      return collection.find(filter, {
        sort: sort,
        limit: limit
      });
    } catch (_error) {
      e = _error;
      return console.log(e);
    }
  });
  collection.find().observe({
    _suppress_initial: true,
    added: function(document) {
      return Houston._collections.collections.update({
        name: name
      }, {
        $inc: {
          count: 1
        },
        $addToSet: {
          fields: {
            $each: Houston._get_fields([document])
          }
        }
      });
    },
    changed: function(document) {
      return Houston._collections.collections.update({
        name: name
      }, {
        $addToSet: {
          fields: {
            $each: Houston._get_fields([document])
          }
        }
      });
    },
    removed: function(document) {
      return Houston._collections.collections.update({
        name: name
      }, {
        $inc: {
          count: -1
        }
      });
    }
  });
  fields = Houston._get_fields_from_collection(collection);
  c = Houston._collections.collections.findOne({
    name: name
  });
  count = collection.find().count();
  if (c) {
    Houston._collections.collections.update(c._id, {
      $set: {
        count: count,
        fields: fields
      }
    });
  } else {
    Houston._collections.collections.insert({
      name: name,
      count: count,
      fields: fields
    });
  }
  return ADDED_COLLECTIONS[name] = collection;
};

sync_collections = function() {
  var _sync_collections, bound_sync_collections, collection, collections, i, len, mongo_driver, ref, ref1;
  Houston._admins.findOne();
  collections = {};
  ref1 = (ref = Mongo.Collection.getAll()) != null ? ref : [];
  for (i = 0, len = ref1.length; i < len; i++) {
    collection = ref1[i];
    collections[collection.name] = collection.instance;
  }
  _sync_collections = function(meh, collections_db) {
    var col, collection_names;
    collection_names = (function() {
      var j, len1, results;
      results = [];
      for (j = 0, len1 = collections_db.length; j < len1; j++) {
        col = collections_db[j];
        if ((col.collectionName.indexOf("system.")) !== 0 && (col.collectionName.indexOf("houston_")) !== 0) {
          results.push(col.collectionName);
        }
      }
      return results;
    })();
    return collection_names.forEach(function(name) {
      if (!(name in ADDED_COLLECTIONS || name in Houston._HIDDEN_COLLECTIONS)) {
        if (collections[name] != null) {
          return Houston._setup_collection(collections[name]);
        }
      }
    });
  };
  bound_sync_collections = Meteor.bindEnvironment(_sync_collections, function(e) {
    return console.log("Failed while syncing collections for reason: " + e);
  });
  mongo_driver = (typeof MongoInternals !== "undefined" && MongoInternals !== null ? MongoInternals.defaultRemoteCollectionDriver() : void 0) || Meteor._RemoteCollectionDriver;
  return mongo_driver.mongo.db.collections(bound_sync_collections);
};

Meteor.methods({
  _houston_make_admin: function(user_id) {
    check(user_id, String);
    if (Houston._admins.findOne({
      'user_id': {
        $exists: true
      }
    })) {
      return;
    }
    Houston._admins.insert({
      user_id: user_id
    });
    Houston._admins.insert({
      exists: true
    });
    sync_collections();
    return true;
  }
});

Houston._publish('collections', function() {
  if (!Houston._user_is_admin(this.userId)) {
    this.ready();
    return;
  }
  return Houston._collections.collections.find();
});

Houston._publish('admin_user', function() {
  if (!Houston._user_is_admin(this.userId)) {
    return Houston._admins.find({
      exists: true
    });
  }
  return Houston._admins.find({});
});

Meteor.startup(function() {
  sync_collections();
  if (Houston._admins.find().count() > 0 && !Houston._admins.findOne({
    exists: true
  })) {
    return Houston._admins.insert({
      exists: true
    });
  }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/houston_admin/server/exports.coffee.js                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var root;

root = typeof exports !== "undefined" && exports !== null ? exports : this;

Houston.add_collection = function(collection) {
  return Houston._setup_collection(collection);
};

Houston.hide_collection = function(collection) {
  var col;
  Houston._HIDDEN_COLLECTIONS[collection._name] = collection;
  col = Houston._collections.collections.findOne({
    name: collection._name
  });
  if (col != null) {
    return Houston._collections.collections.remove(col);
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/houston_admin/server/methods.coffee.js                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var require_admin;

require_admin = function(func) {
  return function() {
    if (Houston._user_is_admin(this.userId)) {
      return func.apply(this, arguments);
    }
  };
};

Houston.methods = function(collection, raw_methods) {
  var collection_name, func, func_name, method_names, methods;
  collection_name = collection.name || collection._name || collection;
  method_names = _(raw_methods).keys();
  Houston._collections.collections.update({
    name: collection_name
  }, {
    $set: {
      method_names: method_names
    }
  });
  methods = {};
  for (func_name in raw_methods) {
    func = raw_methods[func_name];
    methods[Houston._custom_method_name(collection_name, func_name)] = require_admin(func);
  }
  return Meteor.methods(methods);
};

Houston._setup_collection_methods = function(collection) {
  var methods, name;
  name = collection._name;
  methods = {};
  methods[Houston._houstonize(name + "_insert")] = require_admin(function(doc) {
    check(doc, Object);
    return collection.insert(doc);
  });
  methods[Houston._houstonize(name + "_update")] = require_admin(function(id, update_dict) {
    check(id, Match.Any);
    check(update_dict, Object);
    if (collection.findOne(id)) {
      collection.update(id, update_dict);
    } else {
      id = collection.findOne(new Meteor.Collection.ObjectID(id));
      collection.update(id, update_dict);
    }
    return collection._name + " " + id + " saved successfully";
  });
  methods[Houston._houstonize(name + "_delete")] = require_admin(function(id) {
    check(id, Match.Any);
    if (collection.findOne(id)) {
      return collection.remove(id);
    } else {
      id = collection.findOne(new Meteor.Collection.ObjectID(id));
      return collection.remove(id);
    }
  });
  methods[Houston._houstonize(name + "_deleteAll")] = require_admin(function() {
    return collection.remove({});
  });
  return Meteor.methods(methods);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("houston:admin");

})();

//# sourceURL=meteor://💻app/packages/houston_admin.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvaG91c3Rvbl9hZG1pbi9saWIvY29sbGVjdGlvbnMuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9ob3VzdG9uX2FkbWluL2xpYi9zaGFyZWQuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9ob3VzdG9uX2FkbWluL2xpYi9tZW51LmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvaG91c3Rvbl9hZG1pbi9zZXJ2ZXIvcHVibGljYXRpb25zLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvaG91c3Rvbl9hZG1pbi9zZXJ2ZXIvZXhwb3J0cy5jb2ZmZWUiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2hvdXN0b25fYWRtaW4vc2VydmVyL21ldGhvZHMuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7QUFBQSw0REFBTyxVQUFVLElBQWpCOzs7RUFFQSxJQUFJLENBQUMsVUFBVztDQUZoQjs7O0VBSUEsT0FBTyxDQUFDLGVBQWdCO0NBSnhCOztBQUFBLE9BTU8sQ0FBQyxZQUFZLENBQUMsV0FBckIsR0FBdUMsVUFBTSxDQUFDLFVBQVAsQ0FBa0IscUJBQWxCLENBTnZDOztBQUFBLE9BUU8sQ0FBQyxPQUFSLEdBQXNCLFVBQU0sQ0FBQyxVQUFQLENBQWtCLGdCQUFsQixDQVJ0Qjs7QUFBQSxPQVVPLENBQUMsY0FBUixHQUF5QixTQUFDLEVBQUQ7QUFDdkIsU0FBTyxnQkFBUSxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQWhCLENBQXdCO0FBQUEsYUFBUyxFQUFUO0dBQXhCLENBQWYsQ0FEdUI7QUFBQSxDQVZ6Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTs7QUFBQSw0REFBTyxVQUFVLElBQWpCOzs7RUFFQSxJQUFJLENBQUMsVUFBVztDQUZoQjs7QUFBQSxPQUlPLENBQUMsV0FBUixHQUFzQixTQUFDLElBQUQ7U0FBVSxjQUFZLEtBQXRCO0FBQUEsQ0FKdEI7O0FBQUEsT0FNTyxDQUFDLG1CQUFSLEdBQThCLFNBQUMsZUFBRCxFQUFrQixXQUFsQjtTQUM1QixPQUFPLENBQUMsV0FBUixDQUF1QixlQUFELEdBQWlCLEdBQWpCLEdBQW9CLFdBQTFDLEVBRDRCO0FBQUEsQ0FOOUI7O0FBQUEsT0FVTyxDQUFDLG9CQUFSLEdBQStCLEdBVi9COztBQUFBLE9BWU8sQ0FBQywyQkFBUixHQUFzQyxTQUFDLFVBQUQ7U0FFcEMsT0FBTyxDQUFDLFdBQVIsQ0FBb0IsVUFBVSxDQUFDLElBQVgsRUFBaUIsQ0FBQyxLQUFsQixFQUFwQixFQUZvQztBQUFBLENBWnRDOztBQUFBLE9BZ0JPLENBQUMsV0FBUixHQUFzQixTQUFDLFNBQUQsRUFBWSxPQUFaO0FBQ3BCOztJQURnQyxVQUFRO0dBQ3hDO0FBQUEsZ0JBQWlCLDBCQUFILEdBQTRCLEVBQTVCLEdBQW9DO0FBQUEsSUFBQyxLQUFLLFVBQU47R0FBbEQ7QUFBQSxFQUVBLGNBQWMsU0FBQyxRQUFELEVBQVcsTUFBWDtBQUNaOztNQUR1QixTQUFPO0tBQzlCO0FBQUE7QUFBQTtTQUFBO3VCQUFBO0FBQ0UsVUFBRyxpQkFBZ0IsUUFBbkI7QUFHRSxZQUFHLGlCQUFpQixJQUFwQjtBQUNFLDBCQUFnQixLQUFHLE1BQUgsR0FBWSxHQUE1QjtBQUFBLHVCQUNBLFdBQVksZUFBWixHQUE2QixPQUQ3QixDQURGO1NBQUE7dUJBTUUsWUFBWSxLQUFaLEVBQW1CLEtBQUcsTUFBSCxHQUFZLEdBQVosR0FBZ0IsR0FBbkMsR0FORjtTQUhGO09BQUEsTUFVSyxJQUFHLGlCQUFrQixVQUFyQjtBQUNILHdCQUFnQixLQUFHLE1BQUgsR0FBWSxHQUE1QjtBQUFBLHFCQUNBLFdBQVksZUFBWixHQUE2QixhQUQ3QixDQURHO09BQUE7NkJBQUE7T0FYUDtBQUFBO21CQURZO0VBQUEsQ0FGZDtBQWtCQTtBQUFBO3NCQUFBO0FBQ0UsZ0JBQVksUUFBWixFQURGO0FBQUEsR0FsQkE7QUFxQkM7T0FBQTs2QkFBQTtBQUFBO0FBQUEsWUFBTSxHQUFOO0FBQUEsTUFBVyxNQUFNLEtBQWpCO01BQUE7QUFBQTtpQkF0Qm1CO0FBQUEsQ0FoQnRCOztBQUFBLE9Bd0NPLENBQUMsZ0JBQVIsR0FBMkIsU0FBQyxTQUFEO1NBQ3pCLENBQUMsQ0FBQyxLQUFGLENBQVEsT0FBTyxDQUFDLFdBQVIsQ0FBb0IsU0FBcEIsQ0FBUixFQUF3QyxNQUF4QyxFQUR5QjtBQUFBLENBeEMzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTs7QUFBQSw0REFBTyxVQUFVLElBQWpCOzs7RUFFQSxJQUFJLENBQUMsVUFBVztDQUZoQjs7QUFBQSxPQUlPLENBQUMsSUFBUixHQUFlO0FBQ2I7QUFBQTt3QkFBQTtBQUFBLFFBQUMsQ0FBQyxJQUFJLENBQUMsY0FBUCxDQUFzQixJQUF0QjtBQUFBLEdBRGE7QUFBQSxDQUpmOztBQUFBLE9BUU8sQ0FBQyxJQUFJLENBQUMsVUFBYixHQUEwQixRQUFRLENBQUMsVUFSbkM7O0FBQUEsT0FVTyxDQUFDLElBQUksQ0FBQyxXQUFiLEdBQTJCLEVBVjNCOztBQUFBLE9BWU8sQ0FBQyxJQUFJLENBQUMsYUFBYixHQUE2QixTQUFDLElBQUQ7QUFDM0IsTUFBRyxJQUFJLENBQUMsSUFBTCxLQUFlLE1BQWYsSUFBMEIsSUFBSSxDQUFDLElBQUwsS0FBZSxVQUE1QztBQUNFLFVBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSxHQUFiLEVBQWtCLDRCQUE0QixJQUE5QyxDQUFWLENBREY7R0FBQTtBQUdBLE1BQUcsSUFBSSxDQUFDLElBQUwsS0FBYSxNQUFoQjtBQUNFLFFBQUksQ0FBQyxJQUFMLEdBQVksSUFBSSxDQUFDLEdBQWpCLENBREY7R0FBQSxNQUVLLElBQUcsSUFBSSxDQUFDLElBQUwsS0FBYSxVQUFoQjtBQUNILFFBQUksQ0FBQyxJQUFMLEdBQWUsT0FBTyxDQUFDLFdBQVQsR0FBcUIsV0FBckIsR0FBZ0MsSUFBSSxDQUFDLEdBQW5ELENBREc7R0FMTDtBQVFBLFNBQU8sSUFBUCxDQVQyQjtBQUFBLENBWjdCOztBQUFBLE9BdUJPLENBQUMsSUFBSSxDQUFDLGVBQWIsR0FBK0I7QUFDN0I7QUFBQSxNQUFDLFdBQVUsQ0FBQyxNQUFaO0FBQ0E7QUFBQTtPQUFBO2tCQUFBO0FBQUEscUJBQUMsY0FBRCxDQUFlLElBQWY7QUFBQTtpQkFGNkI7QUFBQSxDQXZCL0I7O0FBQUEsT0EyQk8sQ0FBQyxJQUFJLENBQUMsY0FBYixHQUE4QixTQUFDLElBQUQ7QUFDNUIsTUFBQyxZQUFXLENBQUMsSUFBYixDQUFrQixJQUFsQjtTQUNBLElBQUMsV0FBVSxDQUFDLE9BQVosR0FGNEI7QUFBQSxDQTNCOUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7O0FBQUEsNERBQU8sVUFBVSxJQUFqQjs7QUFBQSxPQUNPLENBQUMsbUJBQVIsR0FBOEI7QUFBQSxFQUFDLFNBQVMsTUFBTSxDQUFDLEtBQWpCO0FBQUEsRUFBd0IsNkNBQTZDLE1BQXJFO0NBRDlCOztBQUFBLGlCQUVBLEdBQW9CLEVBRnBCOztBQUFBLE9BS08sQ0FBQyxRQUFSLEdBQW1CLFNBQUMsSUFBRCxFQUFPLElBQVA7U0FDakIsTUFBTSxDQUFDLE9BQVAsQ0FBZSxPQUFPLENBQUMsV0FBUixDQUFvQixJQUFwQixDQUFmLEVBQTBDLElBQTFDLEVBRGlCO0FBQUEsQ0FMbkI7O0FBQUEsT0FRTyxDQUFDLGlCQUFSLEdBQTRCLFNBQUMsVUFBRDtBQUMxQjtBQUFBLFNBQU8sVUFBVSxDQUFDLEtBQWxCO0FBQ0EsTUFBVSxRQUFRLGlCQUFsQjtBQUFBO0dBREE7QUFBQSxFQUdBLE9BQU8sQ0FBQyx5QkFBUixDQUFrQyxVQUFsQyxDQUhBO0FBQUEsRUFLQSxPQUFPLENBQUMsUUFBUixDQUFpQixJQUFqQixFQUF1QixTQUFDLElBQUQsRUFBTyxNQUFQLEVBQWUsS0FBZixFQUFzQixXQUF0QjtBQUNyQjtBQUFBLFVBQU0sSUFBTixFQUFZLEtBQUssQ0FBQyxRQUFOLENBQWUsTUFBZixDQUFaO0FBQUEsSUFDQSxNQUFNLE1BQU4sRUFBYyxLQUFLLENBQUMsUUFBTixDQUFlLE1BQWYsQ0FBZCxDQURBO0FBQUEsSUFFQSxNQUFNLEtBQU4sRUFBYSxLQUFLLENBQUMsUUFBTixDQUFlLE1BQWYsQ0FBYixDQUZBO0FBQUEsSUFHQSxNQUFNLFdBQU4sRUFBbUIsS0FBSyxDQUFDLEdBQXpCLENBSEE7QUFJQSxnQkFBYyxDQUFDLGNBQVIsQ0FBdUIsSUFBQyxPQUF4QixDQUFQO0FBQ0UsVUFBQyxNQUFEO0FBQ0EsYUFGRjtLQUpBO0FBT0E7YUFDRSxVQUFVLENBQUMsSUFBWCxDQUFnQixNQUFoQixFQUF3QjtBQUFBLGNBQU0sSUFBTjtBQUFBLFFBQVksT0FBTyxLQUFuQjtPQUF4QixFQURGO0tBQUE7QUFHRSxNQURJLFVBQ0o7YUFBQSxPQUFPLENBQUMsR0FBUixDQUFZLENBQVosRUFIRjtLQVJxQjtFQUFBLENBQXZCLENBTEE7QUFBQSxFQWtCQSxVQUFVLENBQUMsSUFBWCxFQUFpQixDQUFDLE9BQWxCLENBQ0U7QUFBQSx1QkFBbUIsSUFBbkI7QUFBQSxJQUNBLE9BQU8sU0FBQyxRQUFEO2FBQ0wsT0FBTyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsTUFBakMsQ0FBd0M7QUFBQSxRQUFDLFVBQUQ7T0FBeEMsRUFDRTtBQUFBLGNBQU07QUFBQSxVQUFDLE9BQU8sQ0FBUjtTQUFOO0FBQUEsUUFDQSxXQUFXO0FBQUEsa0JBQVE7QUFBQSxtQkFBTyxPQUFPLENBQUMsV0FBUixDQUFvQixDQUFDLFFBQUQsQ0FBcEIsQ0FBUDtXQUFSO1NBRFg7T0FERixFQURLO0lBQUEsQ0FEUDtBQUFBLElBS0EsU0FBUyxTQUFDLFFBQUQ7YUFDUCxPQUFPLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxNQUFqQyxDQUF3QztBQUFBLFFBQUMsVUFBRDtPQUF4QyxFQUNFO0FBQUEsbUJBQVc7QUFBQSxrQkFBUTtBQUFBLG1CQUFPLE9BQU8sQ0FBQyxXQUFSLENBQW9CLENBQUMsUUFBRCxDQUFwQixDQUFQO1dBQVI7U0FBWDtPQURGLEVBRE87SUFBQSxDQUxUO0FBQUEsSUFRQSxTQUFTLFNBQUMsUUFBRDthQUNQLE9BQU8sQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQWpDLENBQXdDO0FBQUEsUUFBQyxVQUFEO09BQXhDLEVBQWdEO0FBQUEsUUFBQyxNQUFNO0FBQUEsVUFBQyxPQUFPLEVBQVI7U0FBUDtPQUFoRCxFQURPO0lBQUEsQ0FSVDtHQURGLENBbEJBO0FBQUEsRUE4QkEsU0FBUyxPQUFPLENBQUMsMkJBQVIsQ0FBb0MsVUFBcEMsQ0E5QlQ7QUFBQSxFQStCQSxJQUFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLE9BQWpDLENBQXlDO0FBQUEsSUFBQyxVQUFEO0dBQXpDLENBL0JKO0FBQUEsRUFnQ0EsUUFBUSxVQUFVLENBQUMsSUFBWCxFQUFpQixDQUFDLEtBQWxCLEVBaENSO0FBaUNBLE1BQUcsQ0FBSDtBQUNFLFdBQU8sQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQWpDLENBQXdDLENBQUMsQ0FBQyxHQUExQyxFQUErQztBQUFBLE1BQUMsTUFBTTtBQUFBLFFBQUMsWUFBRDtBQUFBLFFBQVEsY0FBUjtPQUFQO0tBQS9DLEVBREY7R0FBQTtBQUdFLFdBQU8sQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQWpDLENBQXdDO0FBQUEsTUFBQyxVQUFEO0FBQUEsTUFBTyxZQUFQO0FBQUEsTUFBYyxjQUFkO0tBQXhDLEVBSEY7R0FqQ0E7U0FxQ0EsaUJBQWtCLE1BQWxCLEdBQTBCLFdBdENBO0FBQUEsQ0FSNUI7O0FBQUEsZ0JBZ0RBLEdBQW1CO0FBQ2pCO0FBQUEsU0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFoQjtBQUFBLEVBRUEsY0FBYyxFQUZkO0FBR0E7QUFBQTt5QkFBQTtBQUNFLGVBQVksV0FBVSxDQUFDLElBQVgsQ0FBWixHQUErQixVQUFVLENBQUMsUUFBMUMsQ0FERjtBQUFBLEdBSEE7QUFBQSxFQU1BLG9CQUFvQixTQUFDLEdBQUQsRUFBTSxjQUFOO0FBQ2xCO0FBQUE7O0FBQW9CO1dBQUE7Z0NBQUE7WUFDYixDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsT0FBbkIsQ0FBMkIsU0FBM0IsQ0FBRCxNQUE0QyxDQUE1QyxJQUNBLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxPQUFuQixDQUEyQixVQUEzQixDQUFELE1BQTZDO0FBRmhDLDBCQUFHLENBQUMsZUFBSjtTQUFBO0FBQUE7O1FBQXBCO1dBSUEsZ0JBQWdCLENBQUMsT0FBakIsQ0FBeUIsU0FBQyxJQUFEO0FBQ3ZCLFlBQU8sUUFBUSxpQkFBUixJQUE2QixRQUFRLE9BQU8sQ0FBQyxtQkFBcEQ7QUFDRSxZQUFnRCx5QkFBaEQ7aUJBQUEsT0FBTyxDQUFDLGlCQUFSLENBQTBCLFdBQVksTUFBdEM7U0FERjtPQUR1QjtJQUFBLENBQXpCLEVBTGtCO0VBQUEsQ0FOcEI7QUFBQSxFQWVBLHlCQUF5QixNQUFNLENBQUMsZUFBUCxDQUF1QixpQkFBdkIsRUFBMEMsU0FBQyxDQUFEO1dBQ2pFLE9BQU8sQ0FBQyxHQUFSLENBQVksa0RBQWdELENBQTVELEVBRGlFO0VBQUEsQ0FBMUMsQ0FmekI7QUFBQSxFQW1CQSxtRkFBZSxjQUFjLENBQUUsNkJBQWhCLGdCQUFtRCxNQUFNLENBQUMsdUJBbkJ6RTtTQW9CQSxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxXQUF0QixDQUFrQyxzQkFBbEMsRUFyQmlCO0FBQUEsQ0FoRG5COztBQUFBLE1BdUVNLENBQUMsT0FBUCxDQUNFO0FBQUEsdUJBQXFCLFNBQUMsT0FBRDtBQUNuQixVQUFNLE9BQU4sRUFBZSxNQUFmO0FBRUEsUUFBVSxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQWhCLENBQXdCO0FBQUEsTUFBQyxXQUFXO0FBQUEsaUJBQVMsSUFBVDtPQUFaO0tBQXhCLENBQVY7QUFBQTtLQUZBO0FBQUEsSUFHQSxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQWhCLENBQXVCO0FBQUEsTUFBQyxnQkFBRDtLQUF2QixDQUhBO0FBQUEsSUFJQSxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQWhCLENBQXVCO0FBQUEsTUFBQyxRQUFRLElBQVQ7S0FBdkIsQ0FKQTtBQUFBLElBS0Esa0JBTEE7QUFNQSxXQUFPLElBQVAsQ0FQbUI7RUFBQSxDQUFyQjtDQURGLENBdkVBOztBQUFBLE9Ba0ZPLENBQUMsUUFBUixDQUFpQixhQUFqQixFQUFnQztBQUM5QixjQUFjLENBQUMsY0FBUixDQUF1QixJQUFDLE9BQXhCLENBQVA7QUFDRSxRQUFDLE1BQUQ7QUFDQSxXQUZGO0dBQUE7U0FHQSxPQUFPLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFqQyxHQUo4QjtBQUFBLENBQWhDLENBbEZBOztBQUFBLE9BeUZPLENBQUMsUUFBUixDQUFpQixZQUFqQixFQUErQjtBQUM3QixjQUFjLENBQUMsY0FBUixDQUF1QixJQUFDLE9BQXhCLENBQVA7QUFDRSxXQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBaEIsQ0FBcUI7QUFBQSxNQUFDLFFBQVEsSUFBVDtLQUFyQixDQUFQLENBREY7R0FBQTtBQUVBLFNBQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFoQixDQUFxQixFQUFyQixDQUFQLENBSDZCO0FBQUEsQ0FBL0IsQ0F6RkE7O0FBQUEsTUE4Rk0sQ0FBQyxPQUFQLENBQWU7QUFDYjtBQUNBLE1BQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFoQixFQUFzQixDQUFDLEtBQXZCLEtBQWlDLENBQWpDLElBQXVDLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBaEIsQ0FBd0I7QUFBQSxJQUFDLFFBQVEsSUFBVDtHQUF4QixDQUEzQztXQUNFLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBaEIsQ0FBdUI7QUFBQSxNQUFDLFFBQVEsSUFBVDtLQUF2QixFQURGO0dBRmE7QUFBQSxDQUFmLENBOUZBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0NBOztBQUFBLDREQUFPLFVBQVUsSUFBakI7O0FBQUEsT0FJTyxDQUFDLGNBQVIsR0FBeUIsU0FBQyxVQUFEO1NBRXZCLE9BQU8sQ0FBQyxpQkFBUixDQUEwQixVQUExQixFQUZ1QjtBQUFBLENBSnpCOztBQUFBLE9BU08sQ0FBQyxlQUFSLEdBQTBCLFNBQUMsVUFBRDtBQUN4QjtBQUFBLFNBQU8sQ0FBQyxtQkFBb0IsV0FBVSxDQUFDLEtBQVgsQ0FBNUIsR0FBZ0QsVUFBaEQ7QUFBQSxFQUNBLE1BQU0sT0FBTyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsT0FBakMsQ0FBeUM7QUFBQSxJQUFDLE1BQU0sVUFBVSxDQUFDLEtBQWxCO0dBQXpDLENBRE47QUFFQSxNQUFnRCxXQUFoRDtXQUFBLE9BQU8sQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQWpDLENBQXdDLEdBQXhDO0dBSHdCO0FBQUEsQ0FUMUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7O0FBQUEsZ0JBQWdCLFNBQUMsSUFBRDtTQUNkO0FBQUcsUUFBNEIsT0FBTyxDQUFDLGNBQVIsQ0FBdUIsSUFBQyxPQUF4QixDQUE1QjthQUFBLElBQUksQ0FBQyxLQUFMLENBQVcsSUFBWCxFQUFjLFNBQWQ7S0FBSDtFQUFBLEVBRGM7QUFBQSxDQUFoQjs7QUFBQSxPQUdPLENBQUMsT0FBUixHQUFrQixTQUFDLFVBQUQsRUFBYSxXQUFiO0FBQ2hCO0FBQUEsb0JBQWtCLFVBQVUsQ0FBQyxJQUFYLElBQW1CLFVBQVUsQ0FBQyxLQUE5QixJQUF1QyxVQUF6RDtBQUFBLEVBQ0EsZUFBZSxFQUFFLFdBQUYsQ0FBYyxDQUFDLElBQWYsRUFEZjtBQUFBLEVBRUEsT0FBTyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsTUFBakMsQ0FBd0M7QUFBQSxJQUFDLE1BQU0sZUFBUDtHQUF4QyxFQUFpRTtBQUFBLElBQUMsTUFBTTtBQUFBLE1BQUMsMEJBQUQ7S0FBUDtHQUFqRSxDQUZBO0FBQUEsRUFJQSxVQUFVLEVBSlY7QUFLQTtrQ0FBQTtBQUNFLFdBQVEsUUFBTyxDQUFDLG1CQUFSLENBQTRCLGVBQTVCLEVBQTZDLFNBQTdDLEVBQVIsR0FBbUUsY0FBYyxJQUFkLENBQW5FLENBREY7QUFBQSxHQUxBO1NBUUEsTUFBTSxDQUFDLE9BQVAsQ0FBZSxPQUFmLEVBVGdCO0FBQUEsQ0FIbEI7O0FBQUEsT0FjTyxDQUFDLHlCQUFSLEdBQW9DLFNBQUMsVUFBRDtBQUNsQztBQUFBLFNBQU8sVUFBVSxDQUFDLEtBQWxCO0FBQUEsRUFDQSxVQUFVLEVBRFY7QUFBQSxFQUVBLE9BQVEsUUFBTyxDQUFDLFdBQVIsQ0FBdUIsSUFBRCxHQUFNLFNBQTVCLEVBQVIsR0FBZ0QsY0FBYyxTQUFDLEdBQUQ7QUFDNUQsVUFBTSxHQUFOLEVBQVcsTUFBWDtXQUNBLFVBQVUsQ0FBQyxNQUFYLENBQWtCLEdBQWxCLEVBRjREO0VBQUEsQ0FBZCxDQUZoRDtBQUFBLEVBTUEsT0FBUSxRQUFPLENBQUMsV0FBUixDQUF1QixJQUFELEdBQU0sU0FBNUIsRUFBUixHQUFnRCxjQUFjLFNBQUMsRUFBRCxFQUFLLFdBQUw7QUFDNUQsVUFBTSxFQUFOLEVBQVUsS0FBSyxDQUFDLEdBQWhCO0FBQUEsSUFDQSxNQUFNLFdBQU4sRUFBbUIsTUFBbkIsQ0FEQTtBQUVBLFFBQUcsVUFBVSxDQUFDLE9BQVgsQ0FBbUIsRUFBbkIsQ0FBSDtBQUNFLGdCQUFVLENBQUMsTUFBWCxDQUFrQixFQUFsQixFQUFzQixXQUF0QixFQURGO0tBQUE7QUFHRSxXQUFLLFVBQVUsQ0FBQyxPQUFYLENBQXVCLFVBQU0sQ0FBQyxVQUFVLENBQUMsUUFBbEIsQ0FBMkIsRUFBM0IsQ0FBdkIsQ0FBTDtBQUFBLE1BQ0EsVUFBVSxDQUFDLE1BQVgsQ0FBa0IsRUFBbEIsRUFBc0IsV0FBdEIsQ0FEQSxDQUhGO0tBRkE7V0FRRyxVQUFVLENBQUMsS0FBWixHQUFrQixHQUFsQixHQUFxQixFQUFyQixHQUF3QixzQkFUa0M7RUFBQSxDQUFkLENBTmhEO0FBQUEsRUFpQkEsT0FBUSxRQUFPLENBQUMsV0FBUixDQUF1QixJQUFELEdBQU0sU0FBNUIsRUFBUixHQUFnRCxjQUFjLFNBQUMsRUFBRDtBQUM1RCxVQUFNLEVBQU4sRUFBVSxLQUFLLENBQUMsR0FBaEI7QUFDQSxRQUFHLFVBQVUsQ0FBQyxPQUFYLENBQW1CLEVBQW5CLENBQUg7YUFDRSxVQUFVLENBQUMsTUFBWCxDQUFrQixFQUFsQixFQURGO0tBQUE7QUFHRSxXQUFLLFVBQVUsQ0FBQyxPQUFYLENBQXVCLFVBQU0sQ0FBQyxVQUFVLENBQUMsUUFBbEIsQ0FBMkIsRUFBM0IsQ0FBdkIsQ0FBTDthQUNBLFVBQVUsQ0FBQyxNQUFYLENBQWtCLEVBQWxCLEVBSkY7S0FGNEQ7RUFBQSxDQUFkLENBakJoRDtBQUFBLEVBeUJBLE9BQVEsUUFBTyxDQUFDLFdBQVIsQ0FBdUIsSUFBRCxHQUFNLFlBQTVCLEVBQVIsR0FBbUQsY0FBYztXQUMvRCxVQUFVLENBQUMsTUFBWCxDQUFrQixFQUFsQixFQUQrRDtFQUFBLENBQWQsQ0F6Qm5EO1NBNEJBLE1BQU0sQ0FBQyxPQUFQLENBQWUsT0FBZixFQTdCa0M7QUFBQSxDQWRwQyIsImZpbGUiOiIvcGFja2FnZXMvaG91c3Rvbl9hZG1pbi5qcyIsInNvdXJjZXNDb250ZW50IjpbInJvb3QgPSBleHBvcnRzID8gdGhpc1xuXG5yb290LkhvdXN0b24gPz0ge31cblxuSG91c3Rvbi5fY29sbGVjdGlvbnMgPz0ge31cblxuSG91c3Rvbi5fY29sbGVjdGlvbnMuY29sbGVjdGlvbnMgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24oJ2hvdXN0b25fY29sbGVjdGlvbnMnKVxuXG5Ib3VzdG9uLl9hZG1pbnMgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24oJ2hvdXN0b25fYWRtaW5zJylcblxuSG91c3Rvbi5fdXNlcl9pc19hZG1pbiA9IChpZCkgLT5cbiAgcmV0dXJuIGlkPyBhbmQgSG91c3Rvbi5fYWRtaW5zLmZpbmRPbmUgdXNlcl9pZDogaWRcbiIsInJvb3QgPSBleHBvcnRzID8gdGhpc1xuXG5yb290LkhvdXN0b24gPz0ge31cblxuSG91c3Rvbi5faG91c3Rvbml6ZSA9IChuYW1lKSAtPiBcIl9ob3VzdG9uXyN7bmFtZX1cIlxuXG5Ib3VzdG9uLl9jdXN0b21fbWV0aG9kX25hbWUgPSAoY29sbGVjdGlvbl9uYW1lLCBtZXRob2RfbmFtZSkgLT5cbiAgSG91c3Rvbi5faG91c3Rvbml6ZShcIiN7Y29sbGVjdGlvbl9uYW1lfS8je21ldGhvZF9uYW1lfVwiKVxuXG4jIGNoYW5nZSBfTUFYX0RPQ1NfVE9fRVhQTE9SRSBpZiB5b3UgbmVlZCB1cyB0byBleHBsb3JlIG1vcmUgZG9jc1xuSG91c3Rvbi5fTUFYX0RPQ1NfVE9fRVhQTE9SRSA9IDEwMFxuXG5Ib3VzdG9uLl9nZXRfZmllbGRzX2Zyb21fY29sbGVjdGlvbiA9IChjb2xsZWN0aW9uKSAtPlxuICAjIFRPRE8oQU1LKSByYW5kb21seSBzYW1wbGUgdGhlIGRvY3VtZW50cyBpbiBxdWVzdGlvblxuICBIb3VzdG9uLl9nZXRfZmllbGRzKGNvbGxlY3Rpb24uZmluZCgpLmZldGNoKCkpXG5cbkhvdXN0b24uX2dldF9maWVsZHMgPSAoZG9jdW1lbnRzLCBvcHRpb25zPXt9KSAtPlxuICBrZXlfdG9fdHlwZSA9IGlmIG9wdGlvbnMuZXhjbHVkZV9pZD8gdGhlbiB7fSBlbHNlIHtfaWQ6ICdPYmplY3RJZCd9XG5cbiAgZmluZF9maWVsZHMgPSAoZG9jdW1lbnQsIHByZWZpeD0nJykgLT5cbiAgICBmb3Iga2V5LCB2YWx1ZSBvZiBfLm9taXQoZG9jdW1lbnQsICdfaWQnKVxuICAgICAgaWYgdHlwZW9mIHZhbHVlIGlzICdvYmplY3QnXG5cbiAgICAgICAgIyBoYW5kbGUgZGF0ZXMgbGlrZSBzdHJpbmdzXG4gICAgICAgIGlmIHZhbHVlIGluc3RhbmNlb2YgRGF0ZVxuICAgICAgICAgIGZ1bGxfcGF0aF9rZXkgPSBcIiN7cHJlZml4fSN7a2V5fVwiXG4gICAgICAgICAga2V5X3RvX3R5cGVbZnVsbF9wYXRoX2tleV0gPSBcIkRhdGVcIlxuXG4gICAgICAgICMgcmVjdXJzZSBpbnRvIHN1YiBkb2N1bWVudHNcbiAgICAgICAgZWxzZVxuICAgICAgICAgIGZpbmRfZmllbGRzIHZhbHVlLCBcIiN7cHJlZml4fSN7a2V5fS5cIlxuICAgICAgZWxzZSBpZiB0eXBlb2YgdmFsdWUgaXNudCAnZnVuY3Rpb24nXG4gICAgICAgIGZ1bGxfcGF0aF9rZXkgPSBcIiN7cHJlZml4fSN7a2V5fVwiXG4gICAgICAgIGtleV90b190eXBlW2Z1bGxfcGF0aF9rZXldID0gdHlwZW9mIHZhbHVlXG5cbiAgZm9yIGRvY3VtZW50IGluIGRvY3VtZW50c1suLkhvdXN0b24uX01BWF9ET0NTX1RPX0VYUExPUkVdXG4gICAgZmluZF9maWVsZHMgZG9jdW1lbnRcblxuICAobmFtZToga2V5LCB0eXBlOiB2YWx1ZSBmb3Iga2V5LCB2YWx1ZSBvZiBrZXlfdG9fdHlwZSlcblxuSG91c3Rvbi5fZ2V0X2ZpZWxkX25hbWVzID0gKGRvY3VtZW50cykgLT5cbiAgXy5wbHVjayhIb3VzdG9uLl9nZXRfZmllbGRzKGRvY3VtZW50cyksICduYW1lJylcbiIsInJvb3QgPSBleHBvcnRzID8gdGhpc1xuXG5yb290LkhvdXN0b24gPz0ge31cblxuSG91c3Rvbi5tZW51ID0gKCkgLT5cbiAgQC5tZW51Ll9hZGRfbWVudV9pdGVtIGl0ZW0gZm9yIGl0ZW0gaW4gYXJndW1lbnRzXG4gIHJldHVyblxuXG5Ib3VzdG9uLm1lbnUuZGVwZW5kZW5jeSA9IG5ldyBEZXBzLkRlcGVuZGVuY3lcblxuSG91c3Rvbi5tZW51Ll9tZW51X2l0ZW1zID0gW11cblxuSG91c3Rvbi5tZW51Ll9wcm9jZXNzX2l0ZW0gPSAoaXRlbSkgLT5cbiAgaWYgaXRlbS50eXBlIGlzbnQgJ2xpbmsnIGFuZCBpdGVtLnR5cGUgaXNudCAndGVtcGxhdGUnXG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciA0MDAsICdDYW5cXCd0IHJlY29nbml6ZSB0eXBlOiAnICsgaXRlbVxuXG4gIGlmIGl0ZW0udHlwZSBpcyAnbGluaydcbiAgICBpdGVtLnBhdGggPSBpdGVtLnVzZVxuICBlbHNlIGlmIGl0ZW0udHlwZSBpcyAndGVtcGxhdGUnXG4gICAgaXRlbS5wYXRoID0gXCIje0hvdXN0b24uX1JPT1RfUk9VVEV9L2FjdGlvbnMvI3tpdGVtLnVzZX1cIlxuXG4gIHJldHVybiBpdGVtXG5cbkhvdXN0b24ubWVudS5fZ2V0X21lbnVfaXRlbXMgPSAtPlxuICBAZGVwZW5kZW5jeS5kZXBlbmQoKVxuICBAX3Byb2Nlc3NfaXRlbSBpdGVtIGZvciBpdGVtIGluIEBfbWVudV9pdGVtc1xuXG5Ib3VzdG9uLm1lbnUuX2FkZF9tZW51X2l0ZW0gPSAoaXRlbSkgLT5cbiAgQF9tZW51X2l0ZW1zLnB1c2ggaXRlbVxuICBAZGVwZW5kZW5jeS5jaGFuZ2VkKClcbiIsInJvb3QgPSBleHBvcnRzID8gdGhpc1xuSG91c3Rvbi5fSElEREVOX0NPTExFQ1RJT05TID0geyd1c2Vycyc6IE1ldGVvci51c2VycywgJ21ldGVvcl9hY2NvdW50c19sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uJzogdW5kZWZpbmVkfVxuQURERURfQ09MTEVDVElPTlMgPSB7fVxuIyBUT0RPOiBkZXNjcmliZSB3aGF0IHRoaXMgaXMsIGV4YWN0bHksIGFuZCBob3cgaXQgZGlmZmVycyBmcm9tIEhvdXN0b24uX2NvbGxlY3Rpb25zLlxuXG5Ib3VzdG9uLl9wdWJsaXNoID0gKG5hbWUsIGZ1bmMpIC0+XG4gIE1ldGVvci5wdWJsaXNoIEhvdXN0b24uX2hvdXN0b25pemUobmFtZSksIGZ1bmNcblxuSG91c3Rvbi5fc2V0dXBfY29sbGVjdGlvbiA9IChjb2xsZWN0aW9uKSAtPlxuICBuYW1lID0gY29sbGVjdGlvbi5fbmFtZVxuICByZXR1cm4gaWYgbmFtZSBvZiBBRERFRF9DT0xMRUNUSU9OU1xuXG4gIEhvdXN0b24uX3NldHVwX2NvbGxlY3Rpb25fbWV0aG9kcyhjb2xsZWN0aW9uKVxuXG4gIEhvdXN0b24uX3B1Ymxpc2ggbmFtZSwgKHNvcnQsIGZpbHRlciwgbGltaXQsIHVua25vd25fYXJnKSAtPlxuICAgIGNoZWNrIHNvcnQsIE1hdGNoLk9wdGlvbmFsKE9iamVjdClcbiAgICBjaGVjayBmaWx0ZXIsIE1hdGNoLk9wdGlvbmFsKE9iamVjdClcbiAgICBjaGVjayBsaW1pdCwgTWF0Y2guT3B0aW9uYWwoTnVtYmVyKVxuICAgIGNoZWNrIHVua25vd25fYXJnLCBNYXRjaC5BbnlcbiAgICB1bmxlc3MgSG91c3Rvbi5fdXNlcl9pc19hZG1pbiBAdXNlcklkXG4gICAgICBAcmVhZHkoKVxuICAgICAgcmV0dXJuXG4gICAgdHJ5XG4gICAgICBjb2xsZWN0aW9uLmZpbmQoZmlsdGVyLCBzb3J0OiBzb3J0LCBsaW1pdDogbGltaXQpXG4gICAgY2F0Y2ggZVxuICAgICAgY29uc29sZS5sb2cgZVxuXG4gIGNvbGxlY3Rpb24uZmluZCgpLm9ic2VydmVcbiAgICBfc3VwcHJlc3NfaW5pdGlhbDogdHJ1ZSAgIyBmaXhlcyBob3VzdG9uIGZvciBsYXJnZSBpbml0aWFsIGRhdGFzZXRzXG4gICAgYWRkZWQ6IChkb2N1bWVudCkgLT5cbiAgICAgIEhvdXN0b24uX2NvbGxlY3Rpb25zLmNvbGxlY3Rpb25zLnVwZGF0ZSB7bmFtZX0sXG4gICAgICAgICRpbmM6IHtjb3VudDogMX0sXG4gICAgICAgICRhZGRUb1NldDogZmllbGRzOiAkZWFjaDogSG91c3Rvbi5fZ2V0X2ZpZWxkcyhbZG9jdW1lbnRdKVxuICAgIGNoYW5nZWQ6IChkb2N1bWVudCkgLT5cbiAgICAgIEhvdXN0b24uX2NvbGxlY3Rpb25zLmNvbGxlY3Rpb25zLnVwZGF0ZSB7bmFtZX0sXG4gICAgICAgICRhZGRUb1NldDogZmllbGRzOiAkZWFjaDogSG91c3Rvbi5fZ2V0X2ZpZWxkcyhbZG9jdW1lbnRdKVxuICAgIHJlbW92ZWQ6IChkb2N1bWVudCkgLT5cbiAgICAgIEhvdXN0b24uX2NvbGxlY3Rpb25zLmNvbGxlY3Rpb25zLnVwZGF0ZSB7bmFtZX0sIHskaW5jOiB7Y291bnQ6IC0xfX1cblxuICBmaWVsZHMgPSBIb3VzdG9uLl9nZXRfZmllbGRzX2Zyb21fY29sbGVjdGlvbihjb2xsZWN0aW9uKVxuICBjID0gSG91c3Rvbi5fY29sbGVjdGlvbnMuY29sbGVjdGlvbnMuZmluZE9uZSB7bmFtZX1cbiAgY291bnQgPSBjb2xsZWN0aW9uLmZpbmQoKS5jb3VudCgpXG4gIGlmIGNcbiAgICBIb3VzdG9uLl9jb2xsZWN0aW9ucy5jb2xsZWN0aW9ucy51cGRhdGUgYy5faWQsIHskc2V0OiB7Y291bnQsIGZpZWxkc319XG4gIGVsc2VcbiAgICBIb3VzdG9uLl9jb2xsZWN0aW9ucy5jb2xsZWN0aW9ucy5pbnNlcnQge25hbWUsIGNvdW50LCBmaWVsZHN9XG4gIEFEREVEX0NPTExFQ1RJT05TW25hbWVdID0gY29sbGVjdGlvblxuXG5zeW5jX2NvbGxlY3Rpb25zID0gLT5cbiAgSG91c3Rvbi5fYWRtaW5zLmZpbmRPbmUoKSAjIFRPRE8gV2h5IGlzIHRoaXMgaGVyZT9cblxuICBjb2xsZWN0aW9ucyA9IHt9XG4gIGZvciBjb2xsZWN0aW9uIGluIChNb25nby5Db2xsZWN0aW9uLmdldEFsbCgpID8gW10pXG4gICAgY29sbGVjdGlvbnNbY29sbGVjdGlvbi5uYW1lXSA9IGNvbGxlY3Rpb24uaW5zdGFuY2VcblxuICBfc3luY19jb2xsZWN0aW9ucyA9IChtZWgsIGNvbGxlY3Rpb25zX2RiKSAtPlxuICAgIGNvbGxlY3Rpb25fbmFtZXMgPSAoY29sLmNvbGxlY3Rpb25OYW1lIGZvciBjb2wgaW4gY29sbGVjdGlvbnNfZGIgXFxcbiAgICAgIHdoZW4gKGNvbC5jb2xsZWN0aW9uTmFtZS5pbmRleE9mIFwic3lzdGVtLlwiKSBpc250IDAgYW5kXG4gICAgICAgICAgIChjb2wuY29sbGVjdGlvbk5hbWUuaW5kZXhPZiBcImhvdXN0b25fXCIpIGlzbnQgMClcblxuICAgIGNvbGxlY3Rpb25fbmFtZXMuZm9yRWFjaCAobmFtZSkgLT5cbiAgICAgIHVubGVzcyBuYW1lIG9mIEFEREVEX0NPTExFQ1RJT05TIG9yIG5hbWUgb2YgSG91c3Rvbi5fSElEREVOX0NPTExFQ1RJT05TXG4gICAgICAgIEhvdXN0b24uX3NldHVwX2NvbGxlY3Rpb24oY29sbGVjdGlvbnNbbmFtZV0pIGlmIGNvbGxlY3Rpb25zW25hbWVdP1xuXG4gIGJvdW5kX3N5bmNfY29sbGVjdGlvbnMgPSBNZXRlb3IuYmluZEVudmlyb25tZW50IF9zeW5jX2NvbGxlY3Rpb25zLCAoZSkgLT5cbiAgICBjb25zb2xlLmxvZyBcIkZhaWxlZCB3aGlsZSBzeW5jaW5nIGNvbGxlY3Rpb25zIGZvciByZWFzb246ICN7ZX1cIlxuXG4gICMgTW9uZ29JbnRlcm5hbHMgaXMgdGhlICdyaWdodCcgc29sdXRpb24gYXMgb2YgMC42LjVcbiAgbW9uZ29fZHJpdmVyID0gTW9uZ29JbnRlcm5hbHM/LmRlZmF1bHRSZW1vdGVDb2xsZWN0aW9uRHJpdmVyKCkgb3IgTWV0ZW9yLl9SZW1vdGVDb2xsZWN0aW9uRHJpdmVyXG4gIG1vbmdvX2RyaXZlci5tb25nby5kYi5jb2xsZWN0aW9ucyBib3VuZF9zeW5jX2NvbGxlY3Rpb25zXG5cbk1ldGVvci5tZXRob2RzXG4gIF9ob3VzdG9uX21ha2VfYWRtaW46ICh1c2VyX2lkKSAtPlxuICAgIGNoZWNrIHVzZXJfaWQsIFN0cmluZ1xuICAgICMgbGltaXQgb25lIGFkbWluXG4gICAgcmV0dXJuIGlmIEhvdXN0b24uX2FkbWlucy5maW5kT25lIHsndXNlcl9pZCc6ICRleGlzdHM6IHRydWV9XG4gICAgSG91c3Rvbi5fYWRtaW5zLmluc2VydCB7dXNlcl9pZH1cbiAgICBIb3VzdG9uLl9hZG1pbnMuaW5zZXJ0IHtleGlzdHM6IHRydWV9XG4gICAgc3luY19jb2xsZWN0aW9ucygpICMgcmVsb2FkcyBjb2xsZWN0aW9ucyBpbiBjYXNlIG9mIG5ldyBhcHBcbiAgICByZXR1cm4gdHJ1ZVxuXG4jIHB1Ymxpc2ggb3VyIGFuYWx5c2lzIG9mIHRoZSBhcHAncyBjb2xsZWN0aW9uc1xuSG91c3Rvbi5fcHVibGlzaCAnY29sbGVjdGlvbnMnLCAtPlxuICB1bmxlc3MgSG91c3Rvbi5fdXNlcl9pc19hZG1pbiBAdXNlcklkXG4gICAgQHJlYWR5KClcbiAgICByZXR1cm5cbiAgSG91c3Rvbi5fY29sbGVjdGlvbnMuY29sbGVjdGlvbnMuZmluZCgpXG5cbiMgVE9ETyBhZGRyZXNzIGluaGVyZW50IHNlY3VyaXR5IGlzc3VlXG5Ib3VzdG9uLl9wdWJsaXNoICdhZG1pbl91c2VyJywgLT5cbiAgdW5sZXNzIEhvdXN0b24uX3VzZXJfaXNfYWRtaW4gQHVzZXJJZFxuICAgIHJldHVybiBIb3VzdG9uLl9hZG1pbnMuZmluZCB7ZXhpc3RzOiB0cnVlfVxuICByZXR1cm4gSG91c3Rvbi5fYWRtaW5zLmZpbmQge31cblxuTWV0ZW9yLnN0YXJ0dXAgLT5cbiAgc3luY19jb2xsZWN0aW9ucygpXG4gIGlmIEhvdXN0b24uX2FkbWlucy5maW5kKCkuY291bnQoKSA+IDAgYW5kICFIb3VzdG9uLl9hZG1pbnMuZmluZE9uZSh7ZXhpc3RzOiB0cnVlfSlcbiAgICBIb3VzdG9uLl9hZG1pbnMuaW5zZXJ0IHtleGlzdHM6IHRydWV9XG4iLCIjIEZ1bmN0aW9ucyB0aGF0IEhvdXN0b24gbWFrZXMgYXZhaWxhYmxlIHRvIHRoZSBhcHBcbnJvb3QgPSBleHBvcnRzID8gdGhpc1xuXG4jIExldCBIb3VzdG9uIGtub3cgYWJvdXQgYSBjb2xsZWN0aW9uIG1hbnVhbGx5LCBhcyBhbiBhbHRlcm5hdGl2ZVxuIyB0byB0aGUgY3VycmVudCBhdXRvZGlzY292ZXJ5IHByb2Nlc3NcbkhvdXN0b24uYWRkX2NvbGxlY3Rpb24gPSAoY29sbGVjdGlvbikgLT5cbiAgIyBUT0RPIG9wdGlvbnMgYXJnIGNhbiBiZSB1c2VkIHRvIGNvbmZpZ3VyZSBhZG1pbiBVSSBsaWtlIERqYW5nbyBkb2VzXG4gIEhvdXN0b24uX3NldHVwX2NvbGxlY3Rpb24oY29sbGVjdGlvbilcblxuIyBIaWRlIGEgY29sbGVjdGlvbiB0aGF0IGlzIG5vdCB3YW50ZWQgaW4gSG91c3RvblxuSG91c3Rvbi5oaWRlX2NvbGxlY3Rpb24gPSAoY29sbGVjdGlvbikgLT5cbiAgSG91c3Rvbi5fSElEREVOX0NPTExFQ1RJT05TW2NvbGxlY3Rpb24uX25hbWVdID0gY29sbGVjdGlvblxuICBjb2wgPSBIb3VzdG9uLl9jb2xsZWN0aW9ucy5jb2xsZWN0aW9ucy5maW5kT25lKHtuYW1lOiBjb2xsZWN0aW9uLl9uYW1lfSlcbiAgSG91c3Rvbi5fY29sbGVjdGlvbnMuY29sbGVjdGlvbnMucmVtb3ZlKGNvbCkgaWYgY29sP1xuIiwiIyBzaGFyZWQgbWV0ZW9yIG1ldGhvZHNcbnJlcXVpcmVfYWRtaW4gPSAoZnVuYykgLT5cbiAgLT4gZnVuYy5hcHBseShALCBhcmd1bWVudHMpIGlmIEhvdXN0b24uX3VzZXJfaXNfYWRtaW4gQHVzZXJJZFxuXG5Ib3VzdG9uLm1ldGhvZHMgPSAoY29sbGVjdGlvbiwgcmF3X21ldGhvZHMpIC0+XG4gIGNvbGxlY3Rpb25fbmFtZSA9IGNvbGxlY3Rpb24ubmFtZSBvciBjb2xsZWN0aW9uLl9uYW1lIG9yIGNvbGxlY3Rpb25cbiAgbWV0aG9kX25hbWVzID0gXyhyYXdfbWV0aG9kcykua2V5cygpXG4gIEhvdXN0b24uX2NvbGxlY3Rpb25zLmNvbGxlY3Rpb25zLnVwZGF0ZSh7bmFtZTogY29sbGVjdGlvbl9uYW1lfSwgeyRzZXQ6IHttZXRob2RfbmFtZXN9fSlcblxuICBtZXRob2RzID0ge31cbiAgZm9yIGZ1bmNfbmFtZSwgZnVuYyBvZiByYXdfbWV0aG9kc1xuICAgIG1ldGhvZHNbSG91c3Rvbi5fY3VzdG9tX21ldGhvZF9uYW1lKGNvbGxlY3Rpb25fbmFtZSwgZnVuY19uYW1lKV0gPSByZXF1aXJlX2FkbWluKGZ1bmMpXG5cbiAgTWV0ZW9yLm1ldGhvZHMgbWV0aG9kc1xuXG5Ib3VzdG9uLl9zZXR1cF9jb2xsZWN0aW9uX21ldGhvZHMgPSAoY29sbGVjdGlvbikgLT5cbiAgbmFtZSA9IGNvbGxlY3Rpb24uX25hbWVcbiAgbWV0aG9kcyA9IHt9XG4gIG1ldGhvZHNbSG91c3Rvbi5faG91c3Rvbml6ZSBcIiN7bmFtZX1faW5zZXJ0XCJdID0gcmVxdWlyZV9hZG1pbiAoZG9jKSAtPlxuICAgIGNoZWNrIGRvYywgT2JqZWN0XG4gICAgY29sbGVjdGlvbi5pbnNlcnQoZG9jKVxuXG4gIG1ldGhvZHNbSG91c3Rvbi5faG91c3Rvbml6ZSBcIiN7bmFtZX1fdXBkYXRlXCJdID0gcmVxdWlyZV9hZG1pbiAoaWQsIHVwZGF0ZV9kaWN0KSAtPlxuICAgIGNoZWNrIGlkLCBNYXRjaC5BbnlcbiAgICBjaGVjayB1cGRhdGVfZGljdCwgT2JqZWN0XG4gICAgaWYgY29sbGVjdGlvbi5maW5kT25lKGlkKVxuICAgICAgY29sbGVjdGlvbi51cGRhdGUoaWQsIHVwZGF0ZV9kaWN0KVxuICAgIGVsc2VcbiAgICAgIGlkID0gY29sbGVjdGlvbi5maW5kT25lKG5ldyBNZXRlb3IuQ29sbGVjdGlvbi5PYmplY3RJRChpZCkpXG4gICAgICBjb2xsZWN0aW9uLnVwZGF0ZShpZCwgdXBkYXRlX2RpY3QpXG5cbiAgICBcIiN7Y29sbGVjdGlvbi5fbmFtZX0gI3tpZH0gc2F2ZWQgc3VjY2Vzc2Z1bGx5XCJcblxuICBtZXRob2RzW0hvdXN0b24uX2hvdXN0b25pemUgXCIje25hbWV9X2RlbGV0ZVwiXSA9IHJlcXVpcmVfYWRtaW4gKGlkKSAtPlxuICAgIGNoZWNrIGlkLCBNYXRjaC5BbnlcbiAgICBpZiBjb2xsZWN0aW9uLmZpbmRPbmUoaWQpXG4gICAgICBjb2xsZWN0aW9uLnJlbW92ZShpZClcbiAgICBlbHNlXG4gICAgICBpZCA9IGNvbGxlY3Rpb24uZmluZE9uZShuZXcgTWV0ZW9yLkNvbGxlY3Rpb24uT2JqZWN0SUQoaWQpKVxuICAgICAgY29sbGVjdGlvbi5yZW1vdmUoaWQpXG5cbiAgbWV0aG9kc1tIb3VzdG9uLl9ob3VzdG9uaXplIFwiI3tuYW1lfV9kZWxldGVBbGxcIl0gPSByZXF1aXJlX2FkbWluICgpIC0+XG4gICAgY29sbGVjdGlvbi5yZW1vdmUoe30pXG5cbiAgTWV0ZW9yLm1ldGhvZHMobWV0aG9kcylcbiJdfQ==
