var require = meteorInstall({"lib":{"collections":{"bookfollow.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/bookfollow.js                                                                  //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Bookfollow = new Meteor.Collection("bookfollow");
////////////////////////////////////////////////////////////////////////////////////////////////////

},"booklist.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/booklist.js                                                                    //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Booklist = new Meteor.Collection("booklist");
////////////////////////////////////////////////////////////////////////////////////////////////////

},"butterflytweets.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/butterflytweets.js                                                             //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Butterfly = new Meteor.Collection("butterfly");
////////////////////////////////////////////////////////////////////////////////////////////////////

},"collections.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/collections.js                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Relationships = new Meteor.Collection("relationships");
////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/comments.js                                                                    //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Comments = new Meteor.Collection("comments");
////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/notifications.js                                                               //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Notifications = new Meteor.Collection("notifications");
////////////////////////////////////////////////////////////////////////////////////////////////////

},"prompts.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/prompts.js                                                                     //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Prompts = new Meteor.Collection("prompts");
////////////////////////////////////////////////////////////////////////////////////////////////////

},"ratings.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/ratings.js                                                                     //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Ratings = new Meteor.Collection('ratings');
////////////////////////////////////////////////////////////////////////////////////////////////////

},"tweets.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/tweets.js                                                                      //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Tweets = new Meteor.Collection("tweets");
////////////////////////////////////////////////////////////////////////////////////////////////////

}},"userUtils.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/userUtils.js                                                                               //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
UserUtils = function () {}; //no var in front


UserUtils.findFollowings = function (username) {
  var currentFollowings = Relationships.find({
    follower: username
  }).fetch().map(function (data) {
    return data.following;
  });
  currentFollowings.push(Meteor.user().username);
  return currentFollowings;
};
////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"js":{"bookprofile.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/bookprofile.js                                                                       //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Meteor.methods({
  'followBook': function (bookid) {
    Bookfollow.insert({
      followername: Meteor.user().username,
      userid: Meteor.userId(),
      following: bookid,
      sawnewChapter: true,
      bookmark: 1
    });
  },
  'unfollowBook': function (bookid) {
    Bookfollow.remove({
      _id: bookid
    });
  },
  'markasNotified': function (bookid) {
    Bookfollow.update({
      followername: Meteor.user().username,
      following: bookid,
      sawnewChapter: false
    }, {
      $set: {
        sawnewChapter: true
      }
    });
  },
  'incViewNumber': function (bookid) {
    Booklist.update({
      _id: bookid
    }, {
      $inc: {
        viewercount: 1
      }
    });
  },
  'removeChapter': function (chapterid) {
    var chapter = Tweets.findOne({
      _id: chapterid,
      user: Meteor.user().username
    });

    if (chapter) {
      var delchapternumber = chapter.chapternumber;
      Tweets.update({
        bookid: chapter.bookid,
        user: Meteor.user().username,
        chapternumber: {
          $gt: delchapternumber
        }
      }, {
        $inc: {
          chapternumber: -1
        }
      }, {
        multi: true
      });
      Booklist.update({
        _id: chapter.bookid
      }, {
        $inc: {
          chaptercount: -1
        }
      });
      Tweets.remove({
        _id: chapterid
      });
    }
  },
  'deleteBook': function (bookid) {
    if (Booklist.find({
      _id: bookid,
      user: Meteor.user().username
    }).count() > 0) {
      Bookfollow.remove({
        following: bookid
      }, {
        multi: true
      });
      Tweets.remove({
        bookid: bookid
      }, {
        multi: true
      });
      Booklist.remove({
        _id: bookid
      });
    }
  },
  'rateBook': function (bookid, rating) {
    if (Ratings.find({
      bookid: bookid,
      user: Meteor.user().username
    }).count() == 0) {
      Ratings.insert({
        bookid: bookid,
        user: Meteor.user().username,
        rating: rating
      });
      var ratings = Ratings.find({
        bookid: bookid
      });
      var count = ratings.count();
      var sum = 0;

      _.forEach(ratings.fetch(), function (item) {
        console.log(item.rating);
        sum += parseFloat(item.rating);
      });

      var avgrating = sum / count;
      console.log("--------");
      console.log("sum: " + sum);
      console.log("count: " + count);
      console.log(avgrating);
      var avground = Math.round(avgrating * 2) / 2;
      Booklist.update({
        _id: bookid
      }, {
        $set: {
          rating: avground
        }
      });
    }
  },
  'updateBookTitle': function (bookid, title) {
    Booklist.update({
      _id: bookid,
      user: Meteor.user().username
    }, {
      $set: {
        booktitle: title
      }
    });
  },
  'updateBookSummary': function (bookid, summary) {
    Booklist.update({
      _id: bookid,
      user: Meteor.user().username
    }, {
      $set: {
        summary: summary
      }
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////

},"chapter.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/chapter.js                                                                           //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Meteor.methods({
  'updateBookmark': function (chapterid) {
    var chapternumber;
    var book;
    var chapter = Tweets.findOne({
      _id: chapterid
    }); //console.log("Bookmark function called");

    if (chapter && Meteor.user.username != null) {
      //console.log(chapter.chapternumber);
      chapternumber = chapter.chapternumber;
      book = chapter.bookid;
      var userfollow = Bookfollow.findOne({
        following: book,
        followername: Meteor.user().username
      });

      if (userfollow) {
        var bookmarknumber = userfollow.bookmark;

        if (chapternumber > bookmarknumber) {
          Bookfollow.update({
            following: book,
            followername: Meteor.user().username
          }, {
            $set: {
              bookmark: chapternumber
            }
          });
        }
      }
    }
  },
  'addComment': function (chapterid, comment) {
    Comments.insert({
      chapterid: chapterid,
      user: Meteor.user().username,
      comment: comment,
      time: new Date()
    });
    Tweets.update({
      _id: chapterid
    }, {
      $inc: {
        newcomments: 1
      }
    });
  },
  'EditChapterTitle': function (chapterid, newtitle) {
    console.log("changing title");
    Tweets.update({
      _id: chapterid,
      user: Meteor.user().username
    }, {
      $set: {
        chaptertitle: newtitle
      }
    });
  },
  'EditChapterMessage': function (chapterid, newmessage) {
    Tweets.update({
      _id: chapterid,
      user: Meteor.user().username
    }, {
      $set: {
        message: newmessage
      }
    });
  },
  'EditChapterVisibility': function (chapterid, visibility) {
    Tweets.update({
      _id: chapterid,
      user: Meteor.user().username
    }, {
      $set: {
        visibility: visibility
      }
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////

},"discover.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/discover.js                                                                          //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////

},"followUsers.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/followUsers.js                                                                       //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Meteor.methods({
  'findUser': function (username) {
    return Meteor.users.findOne({
      username: username
    }, {
      fields: {
        'username': 1
      }
    });
  }
});
Meteor.methods({
  'findUsers': function (username) {
    return Booklist.find({
      booktitle: new RegExp(username, "i")
    }, {
      fields: {
        'booktitle': 1,
        bookid: 1,
        cover: 1,
        user: 1
      }
    }).fetch();
  }
});
Meteor.methods({
  'findUsercount': function (username) {
    return Booklist.find({
      booktitle: new RegExp(username)
    }, {
      fields: {
        'booktitle': 1,
        bookid: 1
      }
    }).count();
  }
});
Meteor.methods({
  'followUser': function (username) {
    Relationships.insert({
      follower: Meteor.user().username,
      following: username
    });
  }
});
Meteor.methods({
  'recommendUsers': function () {
    if (Meteor.user()) {
      var currentFollowings = UserUtils.findFollowings(Meteor.user().username);
      var recUsers = Meteor.users.find({
        username: {
          $nin: currentFollowings
        }
      }, {
        fields: {
          'username': 1
        },
        limit: 5
      }).fetch();
      return recUsers;
    }
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////

},"promptprofile.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/promptprofile.js                                                                     //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////

},"prompts.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/prompts.js                                                                           //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Meteor.methods({
  insertPrompt: function (summary, genres) {
    if (Meteor.user()) {
      Prompts.insert({
        summary: summary,
        genre: genres,
        timestamp: new Date(),
        user: Meteor.user().username
      });
    }
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/publications.js                                                                      //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Meteor.publishComposite('tweets', function (username) {
  return {
    find: function () {
      // Find the current user's following users
      return Relationships.find({
        follower: username
      });
    },
    children: [{
      find: function (relationship) {
        // Find tweets from followed users
        return Tweets.find({
          user: relationship.following
        });
      }
    }]
  };
});
Meteor.publish('ownTweets', function (username) {
  return Tweets.find({
    user: username
  });
});
Meteor.publish('followingBooks', function (username) {
  return Bookfollow.find({
    followername: username
  });
});
Meteor.publish('ownBooks', function (username) {
  return Booklist.find({
    user: username
  });
});
Meteor.publish('hiddenTweets', function (username) {
  return Tweets.find({
    user: username,
    visibility: "Unlisted"
  });
});
Meteor.publish('Books', function () {
  return Booklist.find({});
});
Meteor.publish('Prompts', function () {
  return Prompts.find({});
});
Meteor.publish('Tweets', function () {
  return Tweets.find({
    visibility: "Public"
  });
});
Meteor.publish('bookChapters', function (id) {
  return Tweets.find({
    _id: id
  });
});
Meteor.publish('bookChaptersAll', function (id) {
  return Tweets.find({});
});
Meteor.publish('UserProfile', function (id) {
  return User.find({});
});
Meteor.publish('Ratings', function (id) {
  return Ratings.find({});
});
Meteor.publish('Comments', function (id) {
  return Comments.find({});
});
Meteor.publish('users', function (username) {
  return Meteor.users.find({
    username: username
  }, {
    fields: {
      profile: true
    },
    limit: 100
  });
});
Meteor.publish('Butterfly', function () {
  return Butterfly.find({});
});
Meteor.publish('bookfollow', function () {
  return Bookfollow.find({});
});
Meteor.publish('followings', function (username) {
  return Relationships.find({
    follower: username
  });
});
Meteor.publish('followers', function (username) {
  return Relationships.find({
    following: username
  });
});
Houston.add_collection(Meteor.users);
////////////////////////////////////////////////////////////////////////////////////////////////////

},"startup.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/startup.js                                                                           //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Meteor.startup(function () {
  Relationships._ensureIndex({
    follower: 1,
    following: 1
  }, {
    unique: 1
  });

  Accounts.onCreateUser(function (options, user) {
    if (options.profile) {
      // include the user profile
      user.profile = options.profile;
    } // other user object changes...
    // ...


    return user;
  });
});
////////////////////////////////////////////////////////////////////////////////////////////////////

},"tweetBox.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/tweetBox.js                                                                          //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Meteor.methods({
  insertTweet: function (tweet, title, chaptertitle, visibility) {
    if (Meteor.user()) {
      var book = Booklist.findOne({
        booktitle: title,
        user: Meteor.user().username
      });
      var bookid;

      if (book) {
        bookid = book._id;
      }

      if (bookid) {
        Tweets.insert({
          chaptertitle: chaptertitle,
          message: tweet,
          bookid: bookid,
          chapternumber: book.chaptercount + 1,
          user: Meteor.user().username,
          timestamp: new Date(),
          visibility: visibility
        });
        Booklist.update({
          booktitle: title,
          user: Meteor.user().username
        }, {
          $inc: {
            chaptercount: 1
          }
        });
        Bookfollow.update({
          following: bookid
        }, {
          $set: {
            sawnewChapter: false
          }
        }, {
          multi: true
        });
      }
    }
  },
  insertBook: function (title, cover, tweet, chaptertitle, butter, booksummary, genres, prompt) {
    if (Meteor.user()) {
      console.log(title + "  " + booksummary);

      if (booksummary == "") {
        booksummary = "No summary for this book available";
      }

      Booklist.insert({
        booktitle: title,
        cover: cover,
        chaptercount: 1,
        user: Meteor.user().username,
        viewercount: 1,
        timestamp: new Date(),
        butterfly: butter,
        summary: booksummary,
        genres: genres,
        prompt: prompt
      });
      var book = Booklist.findOne({
        booktitle: title,
        cover: cover,
        user: Meteor.user().username
      });
      var bookid;

      if (book) {
        bookid = book._id;
      }

      var tweetid;

      if (bookid) {
        tweetid = Tweets.insert({
          chaptertitle: chaptertitle,
          message: tweet,
          bookid: bookid,
          chapternumber: 1,
          user: Meteor.user().username,
          timestamp: new Date()
        });
      }

      if (butter) {
        Butterfly.insert({
          chaptertitle: title,
          message: "",
          bookid: bookid,
          chapternumber: 0,
          user: Meteor.user().username,
          timestamp: new Date(),
          parent: null
        });
        var bookbutter;

        if (bookid) {
          bookbutter = Butterfly.findOne({
            bookid: bookid,
            chapternumber: 0
          });
        }

        var butterid;

        if (bookbutter) {
          butterid = bookbutter._id;
        }

        Butterfly.insert({
          chaptertitle: chaptertitle,
          message: tweet,
          bookid: bookid,
          tweetid: tweetid,
          chapternumber: 1,
          user: Meteor.user().username,
          timestamp: new Date(),
          parent: butterid
        });
      }
    }
  },
  insertButterfly: function (tweet, chaptertitle, bookid, currentid) {
    if (Meteor.user()) {
      var book = Booklist.findOne({
        _id: bookid
      });
      var isbutter;

      if (book) {
        isbutter = book.butterfly;
      }

      var currentchapter = Butterfly.findOne({
        tweetid: currentid
      });
      var tweetid;

      if (isbutter) {
        tweetid = Tweets.insert({
          chaptertitle: chaptertitle,
          message: tweet,
          bookid: bookid,
          chapternumber: currentchapter.chapternumber + 1,
          user: Meteor.user().username,
          timestamp: new Date()
        });
        Booklist.update({
          _id: bookid,
          butterfly: true
        }, {
          $inc: {
            chaptercount: 1
          }
        });
        Bookfollow.update({
          following: bookid
        }, {
          $set: {
            sawnewChapter: false
          }
        }, {
          multi: true
        });
        Butterfly.insert({
          chaptertitle: chaptertitle,
          message: tweet,
          bookid: bookid,
          tweetid: tweetid,
          chapternumber: currentchapter.chapternumber + 1,
          user: Meteor.user().username,
          timestamp: new Date(),
          parent: currentchapter._id
        });
      }
    }
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploadForm.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/uploadForm.js                                                                        //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////

},"userManagement.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/js/userManagement.js                                                                    //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
Meteor.methods({
  'setUserRole': function (userid) {
    Roles.addUsersToRoles(userid, ['user', 'can-write']); //  Roles.addUsersToRoles("smZc7sNWEHdkPKE4w", ['admin','user','can-write']);

    console.log("Setting user role for " + userid);
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/lib/collections/bookfollow.js");
require("/lib/collections/booklist.js");
require("/lib/collections/butterflytweets.js");
require("/lib/collections/collections.js");
require("/lib/collections/comments.js");
require("/lib/collections/notifications.js");
require("/lib/collections/prompts.js");
require("/lib/collections/ratings.js");
require("/lib/collections/tweets.js");
require("/lib/userUtils.js");
require("/server/js/bookprofile.js");
require("/server/js/chapter.js");
require("/server/js/discover.js");
require("/server/js/followUsers.js");
require("/server/js/promptprofile.js");
require("/server/js/prompts.js");
require("/server/js/publications.js");
require("/server/js/startup.js");
require("/server/js/tweetBox.js");
require("/server/js/uploadForm.js");
require("/server/js/userManagement.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zL2Jvb2tmb2xsb3cuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9jb2xsZWN0aW9ucy9ib29rbGlzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zL2J1dHRlcmZseXR3ZWV0cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvY29sbGVjdGlvbnMvY29tbWVudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9jb2xsZWN0aW9ucy9ub3RpZmljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvY29sbGVjdGlvbnMvcHJvbXB0cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zL3JhdGluZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9jb2xsZWN0aW9ucy90d2VldHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi91c2VyVXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qcy9ib29rcHJvZmlsZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2pzL2NoYXB0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qcy9mb2xsb3dVc2Vycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2pzL3Byb21wdHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qcy9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qcy9zdGFydHVwLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvanMvdHdlZXRCb3guanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qcy91c2VyTWFuYWdlbWVudC5qcyJdLCJuYW1lcyI6WyJCb29rZm9sbG93IiwiTWV0ZW9yIiwiQ29sbGVjdGlvbiIsIkJvb2tsaXN0IiwiQnV0dGVyZmx5IiwiUmVsYXRpb25zaGlwcyIsIkNvbW1lbnRzIiwiTm90aWZpY2F0aW9ucyIsIlByb21wdHMiLCJSYXRpbmdzIiwiVHdlZXRzIiwiVXNlclV0aWxzIiwiZmluZEZvbGxvd2luZ3MiLCJ1c2VybmFtZSIsImN1cnJlbnRGb2xsb3dpbmdzIiwiZmluZCIsImZvbGxvd2VyIiwiZmV0Y2giLCJtYXAiLCJkYXRhIiwiZm9sbG93aW5nIiwicHVzaCIsInVzZXIiLCJtZXRob2RzIiwiYm9va2lkIiwiaW5zZXJ0IiwiZm9sbG93ZXJuYW1lIiwidXNlcmlkIiwidXNlcklkIiwic2F3bmV3Q2hhcHRlciIsImJvb2ttYXJrIiwicmVtb3ZlIiwiX2lkIiwidXBkYXRlIiwiJHNldCIsIiRpbmMiLCJ2aWV3ZXJjb3VudCIsImNoYXB0ZXJpZCIsImNoYXB0ZXIiLCJmaW5kT25lIiwiZGVsY2hhcHRlcm51bWJlciIsImNoYXB0ZXJudW1iZXIiLCIkZ3QiLCJtdWx0aSIsImNoYXB0ZXJjb3VudCIsImNvdW50IiwicmF0aW5nIiwicmF0aW5ncyIsInN1bSIsIl8iLCJmb3JFYWNoIiwiaXRlbSIsImNvbnNvbGUiLCJsb2ciLCJwYXJzZUZsb2F0IiwiYXZncmF0aW5nIiwiYXZncm91bmQiLCJNYXRoIiwicm91bmQiLCJ0aXRsZSIsImJvb2t0aXRsZSIsInN1bW1hcnkiLCJib29rIiwidXNlcmZvbGxvdyIsImJvb2ttYXJrbnVtYmVyIiwiY29tbWVudCIsInRpbWUiLCJEYXRlIiwibmV3Y29tbWVudHMiLCJuZXd0aXRsZSIsImNoYXB0ZXJ0aXRsZSIsIm5ld21lc3NhZ2UiLCJtZXNzYWdlIiwidmlzaWJpbGl0eSIsInVzZXJzIiwiZmllbGRzIiwiUmVnRXhwIiwiY292ZXIiLCJyZWNVc2VycyIsIiRuaW4iLCJsaW1pdCIsImluc2VydFByb21wdCIsImdlbnJlcyIsImdlbnJlIiwidGltZXN0YW1wIiwicHVibGlzaENvbXBvc2l0ZSIsImNoaWxkcmVuIiwicmVsYXRpb25zaGlwIiwicHVibGlzaCIsImlkIiwiVXNlciIsInByb2ZpbGUiLCJIb3VzdG9uIiwiYWRkX2NvbGxlY3Rpb24iLCJzdGFydHVwIiwiX2Vuc3VyZUluZGV4IiwidW5pcXVlIiwiQWNjb3VudHMiLCJvbkNyZWF0ZVVzZXIiLCJvcHRpb25zIiwiaW5zZXJ0VHdlZXQiLCJ0d2VldCIsImluc2VydEJvb2siLCJidXR0ZXIiLCJib29rc3VtbWFyeSIsInByb21wdCIsImJ1dHRlcmZseSIsInR3ZWV0aWQiLCJwYXJlbnQiLCJib29rYnV0dGVyIiwiYnV0dGVyaWQiLCJpbnNlcnRCdXR0ZXJmbHkiLCJjdXJyZW50aWQiLCJpc2J1dHRlciIsImN1cnJlbnRjaGFwdGVyIiwiUm9sZXMiLCJhZGRVc2Vyc1RvUm9sZXMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUFBLGFBQWEsSUFBSUMsT0FBT0MsVUFBWCxDQUFzQixZQUF0QixDQUFiLEM7Ozs7Ozs7Ozs7O0FDQUFDLFdBQVcsSUFBSUYsT0FBT0MsVUFBWCxDQUFzQixVQUF0QixDQUFYLEM7Ozs7Ozs7Ozs7O0FDQUFFLFlBQVksSUFBSUgsT0FBT0MsVUFBWCxDQUFzQixXQUF0QixDQUFaLEM7Ozs7Ozs7Ozs7O0FDQUFHLGdCQUFnQixJQUFJSixPQUFPQyxVQUFYLENBQXNCLGVBQXRCLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDQUFJLFdBQVcsSUFBSUwsT0FBT0MsVUFBWCxDQUFzQixVQUF0QixDQUFYLEM7Ozs7Ozs7Ozs7O0FDQUFLLGdCQUFnQixJQUFJTixPQUFPQyxVQUFYLENBQXNCLGVBQXRCLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDQUFNLFVBQVUsSUFBSVAsT0FBT0MsVUFBWCxDQUFzQixTQUF0QixDQUFWLEM7Ozs7Ozs7Ozs7O0FDQUFPLFVBQVUsSUFBSVIsT0FBT0MsVUFBWCxDQUFzQixTQUF0QixDQUFWLEM7Ozs7Ozs7Ozs7O0FDQUFRLFNBQVMsSUFBSVQsT0FBT0MsVUFBWCxDQUFzQixRQUF0QixDQUFULEM7Ozs7Ozs7Ozs7O0FDQUFTLFlBQVksWUFBVyxDQUFFLENBQXpCLEMsQ0FBOEI7OztBQUU5QkEsVUFBVUMsY0FBVixHQUEyQixVQUFTQyxRQUFULEVBQW1CO0FBQzVDLE1BQUlDLG9CQUFvQlQsY0FBY1UsSUFBZCxDQUFtQjtBQUN6Q0MsY0FBVUg7QUFEK0IsR0FBbkIsRUFFckJJLEtBRnFCLEdBRWJDLEdBRmEsQ0FFVCxVQUFTQyxJQUFULEVBQWU7QUFDNUIsV0FBT0EsS0FBS0MsU0FBWjtBQUNELEdBSnVCLENBQXhCO0FBS0FOLG9CQUFrQk8sSUFBbEIsQ0FBdUJwQixPQUFPcUIsSUFBUCxHQUFjVCxRQUFyQztBQUVBLFNBQU9DLGlCQUFQO0FBQ0QsQ0FURCxDOzs7Ozs7Ozs7OztBQ0ZBYixPQUFPc0IsT0FBUCxDQUFlO0FBQ2IsZ0JBQWMsVUFBU0MsTUFBVCxFQUFpQjtBQUM3QnhCLGVBQVd5QixNQUFYLENBQWtCO0FBQ2hCQyxvQkFBY3pCLE9BQU9xQixJQUFQLEdBQWNULFFBRFo7QUFFaEJjLGNBQVExQixPQUFPMkIsTUFBUCxFQUZRO0FBR2hCUixpQkFBV0ksTUFISztBQUloQksscUJBQWUsSUFKQztBQUtoQkMsZ0JBQVM7QUFMTyxLQUFsQjtBQVFELEdBVlk7QUFXYixrQkFBZ0IsVUFBU04sTUFBVCxFQUFnQjtBQUM1QnhCLGVBQVcrQixNQUFYLENBQWtCO0FBQUNDLFdBQUlSO0FBQUwsS0FBbEI7QUFFSCxHQWRZO0FBZWIsb0JBQWtCLFVBQVNBLE1BQVQsRUFBZ0I7QUFDOUJ4QixlQUFXaUMsTUFBWCxDQUFrQjtBQUNmUCxvQkFBY3pCLE9BQU9xQixJQUFQLEdBQWNULFFBRGI7QUFFZk8saUJBQVdJLE1BRkk7QUFHZksscUJBQWU7QUFIQSxLQUFsQixFQUlrQjtBQUFDSyxZQUFNO0FBQUNMLHVCQUFjO0FBQWY7QUFBUCxLQUpsQjtBQUtILEdBckJZO0FBc0JiLG1CQUFpQixVQUFTTCxNQUFULEVBQWdCO0FBQzdCckIsYUFBUzhCLE1BQVQsQ0FBZ0I7QUFBQ0QsV0FBS1I7QUFBTixLQUFoQixFQUE4QjtBQUFDVyxZQUFNO0FBQUNDLHFCQUFZO0FBQWI7QUFBUCxLQUE5QjtBQUNILEdBeEJZO0FBeUJiLG1CQUFpQixVQUFTQyxTQUFULEVBQW1CO0FBQ2hDLFFBQUlDLFVBQVM1QixPQUFPNkIsT0FBUCxDQUFlO0FBQUNQLFdBQUlLLFNBQUw7QUFBZWYsWUFBTXJCLE9BQU9xQixJQUFQLEdBQWNUO0FBQW5DLEtBQWYsQ0FBYjs7QUFDQSxRQUFHeUIsT0FBSCxFQUFXO0FBQ1QsVUFBSUUsbUJBQWtCRixRQUFRRyxhQUE5QjtBQUNBL0IsYUFBT3VCLE1BQVAsQ0FBYztBQUFDVCxnQkFBT2MsUUFBUWQsTUFBaEI7QUFBdUJGLGNBQUtyQixPQUFPcUIsSUFBUCxHQUFjVCxRQUExQztBQUFtRDRCLHVCQUFjO0FBQUNDLGVBQUlGO0FBQUw7QUFBakUsT0FBZCxFQUF1RztBQUFDTCxjQUFNO0FBQUNNLHlCQUFlLENBQUM7QUFBakI7QUFBUCxPQUF2RyxFQUFtSTtBQUFDRSxlQUFNO0FBQVAsT0FBbkk7QUFFRXhDLGVBQVM4QixNQUFULENBQWdCO0FBQUNELGFBQUlNLFFBQVFkO0FBQWIsT0FBaEIsRUFBcUM7QUFBQ1csY0FBTTtBQUFDUyx3QkFBYyxDQUFDO0FBQWhCO0FBQVAsT0FBckM7QUFFQWxDLGFBQU9xQixNQUFQLENBQWM7QUFBQ0MsYUFBSUs7QUFBTCxPQUFkO0FBR0g7QUFFSixHQXRDWTtBQXVDYixnQkFBYyxVQUFTYixNQUFULEVBQWdCO0FBQzFCLFFBQUdyQixTQUFTWSxJQUFULENBQWM7QUFBQ2lCLFdBQUlSLE1BQUw7QUFBWUYsWUFBS3JCLE9BQU9xQixJQUFQLEdBQWNUO0FBQS9CLEtBQWQsRUFBd0RnQyxLQUF4RCxLQUFnRSxDQUFuRSxFQUFxRTtBQUNyRTdDLGlCQUFXK0IsTUFBWCxDQUFrQjtBQUFDWCxtQkFBVUk7QUFBWCxPQUFsQixFQUFxQztBQUFDbUIsZUFBTTtBQUFQLE9BQXJDO0FBQ0FqQyxhQUFPcUIsTUFBUCxDQUFjO0FBQUNQLGdCQUFPQTtBQUFSLE9BQWQsRUFBOEI7QUFBQ21CLGVBQU07QUFBUCxPQUE5QjtBQUNBeEMsZUFBUzRCLE1BQVQsQ0FBZ0I7QUFBQ0MsYUFBSVI7QUFBTCxPQUFoQjtBQUVDO0FBRUosR0EvQ1k7QUFnRGIsY0FBWSxVQUFTQSxNQUFULEVBQWdCc0IsTUFBaEIsRUFBdUI7QUFDL0IsUUFBR3JDLFFBQVFNLElBQVIsQ0FBYTtBQUFDUyxjQUFPQSxNQUFSO0FBQWVGLFlBQUtyQixPQUFPcUIsSUFBUCxHQUFjVDtBQUFsQyxLQUFiLEVBQTBEZ0MsS0FBMUQsTUFBbUUsQ0FBdEUsRUFBd0U7QUFDeEVwQyxjQUFRZ0IsTUFBUixDQUFlO0FBQUNELGdCQUFRQSxNQUFUO0FBQWdCRixjQUFNckIsT0FBT3FCLElBQVAsR0FBY1QsUUFBcEM7QUFBNkNpQyxnQkFBUUE7QUFBckQsT0FBZjtBQUNBLFVBQUlDLFVBQVN0QyxRQUFRTSxJQUFSLENBQWE7QUFBQ1MsZ0JBQU9BO0FBQVIsT0FBYixDQUFiO0FBQ0EsVUFBSXFCLFFBQU9FLFFBQVFGLEtBQVIsRUFBWDtBQUNBLFVBQUlHLE1BQUssQ0FBVDs7QUFDRUMsUUFBRUMsT0FBRixDQUFVSCxRQUFROUIsS0FBUixFQUFWLEVBQTBCLFVBQVNrQyxJQUFULEVBQWM7QUFDdkNDLGdCQUFRQyxHQUFSLENBQVlGLEtBQUtMLE1BQWpCO0FBQ0FFLGVBQUtNLFdBQVdILEtBQUtMLE1BQWhCLENBQUw7QUFDQSxPQUhEOztBQUtGLFVBQUlTLFlBQVdQLE1BQUlILEtBQW5CO0FBQ0lPLGNBQVFDLEdBQVIsQ0FBWSxVQUFaO0FBQ0FELGNBQVFDLEdBQVIsQ0FBWSxVQUFRTCxHQUFwQjtBQUNBSSxjQUFRQyxHQUFSLENBQVksWUFBVVIsS0FBdEI7QUFDQU8sY0FBUUMsR0FBUixDQUFZRSxTQUFaO0FBRUosVUFBSUMsV0FBU0MsS0FBS0MsS0FBTCxDQUFXSCxZQUFVLENBQXJCLElBQXdCLENBQXJDO0FBQ0FwRCxlQUFTOEIsTUFBVCxDQUFnQjtBQUFDRCxhQUFJUjtBQUFMLE9BQWhCLEVBQTZCO0FBQUNVLGNBQU07QUFBQ1ksa0JBQU9VO0FBQVI7QUFBUCxPQUE3QjtBQUdDO0FBRUosR0F2RVk7QUF3RWIscUJBQW1CLFVBQVNoQyxNQUFULEVBQWdCbUMsS0FBaEIsRUFBc0I7QUFDckN4RCxhQUFTOEIsTUFBVCxDQUFnQjtBQUFDRCxXQUFJUixNQUFMO0FBQVlGLFlBQUtyQixPQUFPcUIsSUFBUCxHQUFjVDtBQUEvQixLQUFoQixFQUF5RDtBQUFDcUIsWUFBSztBQUFDMEIsbUJBQVVEO0FBQVg7QUFBTixLQUF6RDtBQUVILEdBM0VZO0FBNEViLHVCQUFxQixVQUFTbkMsTUFBVCxFQUFnQnFDLE9BQWhCLEVBQXdCO0FBQ3pDMUQsYUFBUzhCLE1BQVQsQ0FBZ0I7QUFBQ0QsV0FBSVIsTUFBTDtBQUFZRixZQUFLckIsT0FBT3FCLElBQVAsR0FBY1Q7QUFBL0IsS0FBaEIsRUFBeUQ7QUFBQ3FCLFlBQUs7QUFBQzJCLGlCQUFRQTtBQUFUO0FBQU4sS0FBekQ7QUFFSDtBQS9FWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUE1RCxPQUFPc0IsT0FBUCxDQUFlO0FBQ2Isb0JBQWtCLFVBQVNjLFNBQVQsRUFBb0I7QUFDbEMsUUFBSUksYUFBSjtBQUNBLFFBQUlxQixJQUFKO0FBQ0EsUUFBSXhCLFVBQVM1QixPQUFPNkIsT0FBUCxDQUFlO0FBQUNQLFdBQUlLO0FBQUwsS0FBZixDQUFiLENBSGtDLENBSWxDOztBQUNBLFFBQUdDLFdBQVdyQyxPQUFPcUIsSUFBUCxDQUFZVCxRQUFaLElBQXNCLElBQXBDLEVBQXlDO0FBQ3JDO0FBQ0E0QixzQkFBY0gsUUFBUUcsYUFBdEI7QUFDQXFCLGFBQUt4QixRQUFRZCxNQUFiO0FBQ0EsVUFBSXVDLGFBQVkvRCxXQUFXdUMsT0FBWCxDQUFtQjtBQUFDbkIsbUJBQVUwQyxJQUFYO0FBQWdCcEMsc0JBQWF6QixPQUFPcUIsSUFBUCxHQUFjVDtBQUEzQyxPQUFuQixDQUFoQjs7QUFDQSxVQUFHa0QsVUFBSCxFQUFjO0FBQ2QsWUFBSUMsaUJBQWdCRCxXQUFXakMsUUFBL0I7O0FBQ0EsWUFBR1csZ0JBQWN1QixjQUFqQixFQUFnQztBQUMvQmhFLHFCQUFXaUMsTUFBWCxDQUFrQjtBQUFDYix1QkFBVTBDLElBQVg7QUFBZ0JwQywwQkFBYXpCLE9BQU9xQixJQUFQLEdBQWNUO0FBQTNDLFdBQWxCLEVBQXVFO0FBQUNxQixrQkFBSztBQUFDSix3QkFBVVc7QUFBWDtBQUFOLFdBQXZFO0FBR0E7QUFDQTtBQUNKO0FBRUosR0FyQlk7QUFzQlgsZ0JBQWMsVUFBU0osU0FBVCxFQUFvQjRCLE9BQXBCLEVBQTRCO0FBQ3RDM0QsYUFBU21CLE1BQVQsQ0FBZ0I7QUFDaEJZLGlCQUFXQSxTQURLO0FBRWhCZixZQUFNckIsT0FBT3FCLElBQVAsR0FBY1QsUUFGSjtBQUdoQm9ELGVBQVNBLE9BSE87QUFJaEJDLFlBQU0sSUFBSUMsSUFBSjtBQUpVLEtBQWhCO0FBT0F6RCxXQUFPdUIsTUFBUCxDQUFjO0FBQ2RELFdBQUlLO0FBRFUsS0FBZCxFQUNlO0FBQUNGLFlBQU07QUFBQ2lDLHFCQUFhO0FBQWQ7QUFBUCxLQURmO0FBSUgsR0FsQ1U7QUFtQ1gsc0JBQW9CLFVBQVMvQixTQUFULEVBQW9CZ0MsUUFBcEIsRUFBNkI7QUFDN0NqQixZQUFRQyxHQUFSLENBQVksZ0JBQVo7QUFDQTNDLFdBQU91QixNQUFQLENBQWM7QUFDZEQsV0FBS0ssU0FEUztBQUVkZixZQUFNckIsT0FBT3FCLElBQVAsR0FBY1Q7QUFGTixLQUFkLEVBR0U7QUFBQ3FCLFlBQUs7QUFBQ29DLHNCQUFjRDtBQUFmO0FBQU4sS0FIRjtBQUtILEdBMUNVO0FBMkNYLHdCQUFzQixVQUFTaEMsU0FBVCxFQUFvQmtDLFVBQXBCLEVBQStCO0FBQ2pEN0QsV0FBT3VCLE1BQVAsQ0FBYztBQUNkRCxXQUFLSyxTQURTO0FBRWRmLFlBQU1yQixPQUFPcUIsSUFBUCxHQUFjVDtBQUZOLEtBQWQsRUFHRTtBQUFDcUIsWUFBSztBQUFDc0MsaUJBQVNEO0FBQVY7QUFBTixLQUhGO0FBS0gsR0FqRFU7QUFrRFgsMkJBQXlCLFVBQVNsQyxTQUFULEVBQW9Cb0MsVUFBcEIsRUFBK0I7QUFDcEQvRCxXQUFPdUIsTUFBUCxDQUFjO0FBQ2RELFdBQUtLLFNBRFM7QUFFZGYsWUFBTXJCLE9BQU9xQixJQUFQLEdBQWNUO0FBRk4sS0FBZCxFQUdFO0FBQUNxQixZQUFLO0FBQUN1QyxvQkFBWUE7QUFBYjtBQUFOLEtBSEY7QUFLSDtBQXhEVSxDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBeEUsT0FBT3NCLE9BQVAsQ0FBZTtBQUNiLGNBQVksVUFBU1YsUUFBVCxFQUFtQjtBQUM3QixXQUFPWixPQUFPeUUsS0FBUCxDQUFhbkMsT0FBYixDQUFxQjtBQUMxQjFCLGdCQUFVQTtBQURnQixLQUFyQixFQUVKO0FBQ0Q4RCxjQUFRO0FBQUUsb0JBQVk7QUFBZDtBQURQLEtBRkksQ0FBUDtBQUtEO0FBUFksQ0FBZjtBQVdBMUUsT0FBT3NCLE9BQVAsQ0FBZTtBQUNiLGVBQWEsVUFBU1YsUUFBVCxFQUFtQjtBQUM5QixXQUFPVixTQUFTWSxJQUFULENBQWM7QUFDbkI2QyxpQkFBVSxJQUFJZ0IsTUFBSixDQUFXL0QsUUFBWCxFQUFvQixHQUFwQjtBQURTLEtBQWQsRUFFSjtBQUNEOEQsY0FBUTtBQUFFLHFCQUFhLENBQWY7QUFBa0JuRCxnQkFBUSxDQUExQjtBQUE2QnFELGVBQU0sQ0FBbkM7QUFBc0N2RCxjQUFLO0FBQTNDO0FBRFAsS0FGSSxFQUlKTCxLQUpJLEVBQVA7QUFLRDtBQVBZLENBQWY7QUFVQWhCLE9BQU9zQixPQUFQLENBQWU7QUFDYixtQkFBaUIsVUFBU1YsUUFBVCxFQUFtQjtBQUNsQyxXQUFPVixTQUFTWSxJQUFULENBQWM7QUFDbkI2QyxpQkFBVyxJQUFJZ0IsTUFBSixDQUFXL0QsUUFBWDtBQURRLEtBQWQsRUFDNkI7QUFDbEM4RCxjQUFRO0FBQUUscUJBQWEsQ0FBZjtBQUFtQm5ELGdCQUFRO0FBQTNCO0FBRDBCLEtBRDdCLEVBR0pxQixLQUhJLEVBQVA7QUFJRDtBQU5ZLENBQWY7QUFTQTVDLE9BQU9zQixPQUFQLENBQWU7QUFDYixnQkFBYyxVQUFTVixRQUFULEVBQW1CO0FBQy9CUixrQkFBY29CLE1BQWQsQ0FBcUI7QUFDbkJULGdCQUFVZixPQUFPcUIsSUFBUCxHQUFjVCxRQURMO0FBRW5CTyxpQkFBV1A7QUFGUSxLQUFyQjtBQUlEO0FBTlksQ0FBZjtBQVNBWixPQUFPc0IsT0FBUCxDQUFlO0FBQ2Isb0JBQWtCLFlBQVc7QUFDM0IsUUFBSXRCLE9BQU9xQixJQUFQLEVBQUosRUFBbUI7QUFDakIsVUFBSVIsb0JBQW9CSCxVQUFVQyxjQUFWLENBQXlCWCxPQUFPcUIsSUFBUCxHQUFjVCxRQUF2QyxDQUF4QjtBQUVBLFVBQUlpRSxXQUFXN0UsT0FBT3lFLEtBQVAsQ0FBYTNELElBQWIsQ0FBa0I7QUFDL0JGLGtCQUFVO0FBQ1JrRSxnQkFBTWpFO0FBREU7QUFEcUIsT0FBbEIsRUFJWjtBQUNENkQsZ0JBQVE7QUFBRSxzQkFBWTtBQUFkLFNBRFA7QUFFREssZUFBTztBQUZOLE9BSlksRUFPWi9ELEtBUFksRUFBZjtBQVNBLGFBQU82RCxRQUFQO0FBQ0Q7QUFDRjtBQWhCWSxDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZDQTdFLE9BQU9zQixPQUFQLENBQWU7QUFDYjBELGdCQUFjLFVBQVNwQixPQUFULEVBQWlCcUIsTUFBakIsRUFBeUI7QUFDckMsUUFBSWpGLE9BQU9xQixJQUFQLEVBQUosRUFBbUI7QUFDZmQsY0FBUWlCLE1BQVIsQ0FBZTtBQUNYb0MsaUJBQVNBLE9BREU7QUFFWHNCLGVBQU9ELE1BRkk7QUFHWEUsbUJBQVcsSUFBSWpCLElBQUosRUFIQTtBQUlYN0MsY0FBTXJCLE9BQU9xQixJQUFQLEdBQWNUO0FBSlQsT0FBZjtBQU9IO0FBQ0Y7QUFYWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQUFaLE9BQU9vRixnQkFBUCxDQUF3QixRQUF4QixFQUFrQyxVQUFTeEUsUUFBVCxFQUFtQjtBQUNuRCxTQUFPO0FBQ0xFLFVBQU0sWUFBVztBQUNmO0FBQ0EsYUFBT1YsY0FBY1UsSUFBZCxDQUFtQjtBQUFFQyxrQkFBVUg7QUFBWixPQUFuQixDQUFQO0FBQ0QsS0FKSTtBQUtMeUUsY0FBVSxDQUFDO0FBQ1R2RSxZQUFNLFVBQVN3RSxZQUFULEVBQXVCO0FBQzNCO0FBQ0EsZUFBTzdFLE9BQU9LLElBQVAsQ0FBWTtBQUFDTyxnQkFBTWlFLGFBQWFuRTtBQUFwQixTQUFaLENBQVA7QUFDRDtBQUpRLEtBQUQ7QUFMTCxHQUFQO0FBWUQsQ0FiRDtBQWVBbkIsT0FBT3VGLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFVBQVMzRSxRQUFULEVBQW1CO0FBQzdDLFNBQU9ILE9BQU9LLElBQVAsQ0FBWTtBQUFDTyxVQUFNVDtBQUFQLEdBQVosQ0FBUDtBQUNELENBRkQ7QUFJQVosT0FBT3VGLE9BQVAsQ0FBZSxnQkFBZixFQUFpQyxVQUFTM0UsUUFBVCxFQUFtQjtBQUNsRCxTQUFPYixXQUFXZSxJQUFYLENBQWdCO0FBQUNXLGtCQUFjYjtBQUFmLEdBQWhCLENBQVA7QUFDRCxDQUZEO0FBSUFaLE9BQU91RixPQUFQLENBQWUsVUFBZixFQUEyQixVQUFTM0UsUUFBVCxFQUFtQjtBQUM1QyxTQUFPVixTQUFTWSxJQUFULENBQWM7QUFBQ08sVUFBTVQ7QUFBUCxHQUFkLENBQVA7QUFDRCxDQUZEO0FBSUFaLE9BQU91RixPQUFQLENBQWUsY0FBZixFQUErQixVQUFTM0UsUUFBVCxFQUFtQjtBQUNoRCxTQUFPSCxPQUFPSyxJQUFQLENBQVk7QUFBQ08sVUFBTVQsUUFBUDtBQUFpQjRELGdCQUFZO0FBQTdCLEdBQVosQ0FBUDtBQUNELENBRkQ7QUFJQXhFLE9BQU91RixPQUFQLENBQWUsT0FBZixFQUF3QixZQUFXO0FBQ2pDLFNBQU9yRixTQUFTWSxJQUFULENBQWMsRUFBZCxDQUFQO0FBQ0QsQ0FGRDtBQUlBZCxPQUFPdUYsT0FBUCxDQUFlLFNBQWYsRUFBMEIsWUFBVztBQUNuQyxTQUFPaEYsUUFBUU8sSUFBUixDQUFhLEVBQWIsQ0FBUDtBQUNELENBRkQ7QUFJQWQsT0FBT3VGLE9BQVAsQ0FBZSxRQUFmLEVBQXlCLFlBQVc7QUFDbEMsU0FBTzlFLE9BQU9LLElBQVAsQ0FBWTtBQUFDMEQsZ0JBQVc7QUFBWixHQUFaLENBQVA7QUFDRCxDQUZEO0FBSUF4RSxPQUFPdUYsT0FBUCxDQUFlLGNBQWYsRUFBK0IsVUFBU0MsRUFBVCxFQUFhO0FBQzFDLFNBQU8vRSxPQUFPSyxJQUFQLENBQVk7QUFBQ2lCLFNBQUt5RDtBQUFOLEdBQVosQ0FBUDtBQUNELENBRkQ7QUFJQXhGLE9BQU91RixPQUFQLENBQWUsaUJBQWYsRUFBa0MsVUFBU0MsRUFBVCxFQUFhO0FBQzdDLFNBQU8vRSxPQUFPSyxJQUFQLENBQVksRUFBWixDQUFQO0FBQ0QsQ0FGRDtBQUlBZCxPQUFPdUYsT0FBUCxDQUFlLGFBQWYsRUFBOEIsVUFBU0MsRUFBVCxFQUFhO0FBQ3pDLFNBQU9DLEtBQUszRSxJQUFMLENBQVUsRUFBVixDQUFQO0FBQ0QsQ0FGRDtBQUlBZCxPQUFPdUYsT0FBUCxDQUFlLFNBQWYsRUFBMEIsVUFBU0MsRUFBVCxFQUFhO0FBQ3JDLFNBQU9oRixRQUFRTSxJQUFSLENBQWEsRUFBYixDQUFQO0FBQ0QsQ0FGRDtBQUlBZCxPQUFPdUYsT0FBUCxDQUFlLFVBQWYsRUFBMkIsVUFBU0MsRUFBVCxFQUFhO0FBQ3RDLFNBQU9uRixTQUFTUyxJQUFULENBQWMsRUFBZCxDQUFQO0FBQ0QsQ0FGRDtBQUlBZCxPQUFPdUYsT0FBUCxDQUFlLE9BQWYsRUFBd0IsVUFBUzNFLFFBQVQsRUFBbUI7QUFDekMsU0FBT1osT0FBT3lFLEtBQVAsQ0FBYTNELElBQWIsQ0FBa0I7QUFBQ0YsY0FBVUE7QUFBWCxHQUFsQixFQUF3QztBQUM3QzhELFlBQVE7QUFBRWdCLGVBQVE7QUFBVixLQURxQztBQUU3Q1gsV0FBTztBQUZzQyxHQUF4QyxDQUFQO0FBSUQsQ0FMRDtBQVFFL0UsT0FBT3VGLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFlBQVk7QUFDdEMsU0FBT3BGLFVBQVVXLElBQVYsQ0FBZSxFQUFmLENBQVA7QUFDRCxDQUZEO0FBT0ZkLE9BQU91RixPQUFQLENBQWUsWUFBZixFQUE2QixZQUFXO0FBQ3RDLFNBQU94RixXQUFXZSxJQUFYLENBQWdCLEVBQWhCLENBQVA7QUFDRCxDQUZEO0FBSUFkLE9BQU91RixPQUFQLENBQWUsWUFBZixFQUE2QixVQUFTM0UsUUFBVCxFQUFtQjtBQUM5QyxTQUFPUixjQUFjVSxJQUFkLENBQW1CO0FBQUVDLGNBQVVIO0FBQVosR0FBbkIsQ0FBUDtBQUNELENBRkQ7QUFJQVosT0FBT3VGLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFVBQVMzRSxRQUFULEVBQW1CO0FBQzdDLFNBQU9SLGNBQWNVLElBQWQsQ0FBbUI7QUFBRUssZUFBV1A7QUFBYixHQUFuQixDQUFQO0FBQ0QsQ0FGRDtBQU1BK0UsUUFBUUMsY0FBUixDQUF1QjVGLE9BQU95RSxLQUE5QixFOzs7Ozs7Ozs7OztBQzVGQXpFLE9BQU82RixPQUFQLENBQWUsWUFBWTtBQUd6QnpGLGdCQUFjMEYsWUFBZCxDQUEyQjtBQUFDL0UsY0FBVSxDQUFYO0FBQWNJLGVBQVc7QUFBekIsR0FBM0IsRUFBd0Q7QUFBQzRFLFlBQVE7QUFBVCxHQUF4RDs7QUFFRkMsV0FBU0MsWUFBVCxDQUFzQixVQUFVQyxPQUFWLEVBQW1CN0UsSUFBbkIsRUFBeUI7QUFHM0MsUUFBSTZFLFFBQVFSLE9BQVosRUFBcUI7QUFDbkI7QUFDQXJFLFdBQUtxRSxPQUFMLEdBQWVRLFFBQVFSLE9BQXZCO0FBRUQsS0FQMEMsQ0FTM0M7QUFDQTs7O0FBRUEsV0FBT3JFLElBQVA7QUFDRCxHQWJIO0FBa0JDLENBdkJELEU7Ozs7Ozs7Ozs7O0FDQUFyQixPQUFPc0IsT0FBUCxDQUFlO0FBQ2I2RSxlQUFhLFVBQVNDLEtBQVQsRUFBZTFDLEtBQWYsRUFBcUJXLFlBQXJCLEVBQWtDRyxVQUFsQyxFQUE4QztBQUN6RCxRQUFJeEUsT0FBT3FCLElBQVAsRUFBSixFQUFtQjtBQUNmLFVBQUl3QyxPQUFNM0QsU0FBU29DLE9BQVQsQ0FBaUI7QUFBQ3FCLG1CQUFVRCxLQUFYO0FBQWlCckMsY0FBS3JCLE9BQU9xQixJQUFQLEdBQWNUO0FBQXBDLE9BQWpCLENBQVY7QUFDQSxVQUFJVyxNQUFKOztBQUNBLFVBQUdzQyxJQUFILEVBQVE7QUFDSnRDLGlCQUFPc0MsS0FBSzlCLEdBQVo7QUFDSDs7QUFDSCxVQUFHUixNQUFILEVBQVU7QUFDVmQsZUFBT2UsTUFBUCxDQUFjO0FBQ1o2Qyx3QkFBY0EsWUFERjtBQUVaRSxtQkFBUzZCLEtBRkc7QUFHWjdFLGtCQUFRQSxNQUhJO0FBSVppQix5QkFBZXFCLEtBQUtsQixZQUFMLEdBQWtCLENBSnJCO0FBS1p0QixnQkFBTXJCLE9BQU9xQixJQUFQLEdBQWNULFFBTFI7QUFNWnVFLHFCQUFXLElBQUlqQixJQUFKLEVBTkM7QUFPWk0sc0JBQVdBO0FBUEMsU0FBZDtBQVNBdEUsaUJBQVM4QixNQUFULENBQWdCO0FBQUMyQixxQkFBVUQsS0FBWDtBQUFrQnJDLGdCQUFNckIsT0FBT3FCLElBQVAsR0FBY1Q7QUFBdEMsU0FBaEIsRUFBZ0U7QUFBQ3NCLGdCQUFNO0FBQUNTLDBCQUFjO0FBQWY7QUFBUCxTQUFoRTtBQUVBNUMsbUJBQVdpQyxNQUFYLENBQWtCO0FBQUNiLHFCQUFVSTtBQUFYLFNBQWxCLEVBQXFDO0FBQUNVLGdCQUFLO0FBQUNMLDJCQUFjO0FBQWY7QUFBTixTQUFyQyxFQUFrRTtBQUFDYyxpQkFBTTtBQUFQLFNBQWxFO0FBQ0M7QUFHRjtBQUNGLEdBekJZO0FBMkJiMkQsY0FBWSxVQUFTM0MsS0FBVCxFQUFla0IsS0FBZixFQUFxQndCLEtBQXJCLEVBQTJCL0IsWUFBM0IsRUFBeUNpQyxNQUF6QyxFQUFpREMsV0FBakQsRUFBNkR0QixNQUE3RCxFQUFvRXVCLE1BQXBFLEVBQTRFO0FBQ3RGLFFBQUl4RyxPQUFPcUIsSUFBUCxFQUFKLEVBQW1CO0FBQ2Y4QixjQUFRQyxHQUFSLENBQVlNLFFBQU8sSUFBUCxHQUFhNkMsV0FBekI7O0FBQ0EsVUFBR0EsZUFBZSxFQUFsQixFQUFxQjtBQUNwQkEsc0JBQWMsb0NBQWQ7QUFDQTs7QUFDSHJHLGVBQVNzQixNQUFULENBQWdCO0FBQ2RtQyxtQkFBV0QsS0FERztBQUVka0IsZUFBT0EsS0FGTztBQUdkakMsc0JBQWMsQ0FIQTtBQUlkdEIsY0FBTXJCLE9BQU9xQixJQUFQLEdBQWNULFFBSk47QUFLZHVCLHFCQUFZLENBTEU7QUFNZGdELG1CQUFXLElBQUlqQixJQUFKLEVBTkc7QUFPZHVDLG1CQUFVSCxNQVBJO0FBUVoxQyxpQkFBUzJDLFdBUkc7QUFTWnRCLGdCQUFRQSxNQVRJO0FBVVp1QixnQkFBT0E7QUFWSyxPQUFoQjtBQWFFLFVBQUkzQyxPQUFNM0QsU0FBU29DLE9BQVQsQ0FBaUI7QUFBQ3FCLG1CQUFVRCxLQUFYO0FBQWlCa0IsZUFBTUEsS0FBdkI7QUFBNkJ2RCxjQUFLckIsT0FBT3FCLElBQVAsR0FBY1Q7QUFBaEQsT0FBakIsQ0FBVjtBQUNBLFVBQUlXLE1BQUo7O0FBQ0EsVUFBR3NDLElBQUgsRUFBUTtBQUNKdEMsaUJBQU9zQyxLQUFLOUIsR0FBWjtBQUNIOztBQUNELFVBQUkyRSxPQUFKOztBQUNBLFVBQUduRixNQUFILEVBQVU7QUFDVm1GLGtCQUFXakcsT0FBT2UsTUFBUCxDQUFjO0FBQ3pCNkMsd0JBQWNBLFlBRFc7QUFFekJFLG1CQUFTNkIsS0FGZ0I7QUFHekI3RSxrQkFBUUEsTUFIaUI7QUFJekJpQix5QkFBZSxDQUpVO0FBS3pCbkIsZ0JBQU1yQixPQUFPcUIsSUFBUCxHQUFjVCxRQUxLO0FBTXpCdUUscUJBQVcsSUFBSWpCLElBQUo7QUFOYyxTQUFkLENBQVg7QUFRQzs7QUFFRCxVQUFHb0MsTUFBSCxFQUFVO0FBQ1BuRyxrQkFBVXFCLE1BQVYsQ0FBaUI7QUFDcEI2Qyx3QkFBY1gsS0FETTtBQUVwQmEsbUJBQVMsRUFGVztBQUdwQmhELGtCQUFRQSxNQUhZO0FBSXBCaUIseUJBQWUsQ0FKSztBQUtwQm5CLGdCQUFNckIsT0FBT3FCLElBQVAsR0FBY1QsUUFMQTtBQU1wQnVFLHFCQUFXLElBQUlqQixJQUFKLEVBTlM7QUFPcEJ5QyxrQkFBUTtBQVBZLFNBQWpCO0FBU0MsWUFBSUMsVUFBSjs7QUFDQSxZQUFHckYsTUFBSCxFQUFVO0FBQ2RxRix1QkFBV3pHLFVBQVVtQyxPQUFWLENBQWtCO0FBQUNmLG9CQUFRQSxNQUFUO0FBQWlCaUIsMkJBQWM7QUFBL0IsV0FBbEIsQ0FBWDtBQUNDOztBQUNELFlBQUlxRSxRQUFKOztBQUNBLFlBQUdELFVBQUgsRUFBYztBQUNWQyxxQkFBU0QsV0FBVzdFLEdBQXBCO0FBQ0g7O0FBRUc1QixrQkFBVXFCLE1BQVYsQ0FBaUI7QUFDckI2Qyx3QkFBY0EsWUFETztBQUVyQkUsbUJBQVM2QixLQUZZO0FBR3JCN0Usa0JBQVFBLE1BSGE7QUFJckJtRixtQkFBU0EsT0FKWTtBQUtyQmxFLHlCQUFlLENBTE07QUFNckJuQixnQkFBTXJCLE9BQU9xQixJQUFQLEdBQWNULFFBTkM7QUFPckJ1RSxxQkFBVyxJQUFJakIsSUFBSixFQVBVO0FBUXJCeUMsa0JBQVFFO0FBUmEsU0FBakI7QUFXSDtBQUNKO0FBQ0YsR0EvRlk7QUFnR2JDLG1CQUFpQixVQUFTVixLQUFULEVBQWUvQixZQUFmLEVBQTRCOUMsTUFBNUIsRUFBbUN3RixTQUFuQyxFQUE4QztBQUM3RCxRQUFJL0csT0FBT3FCLElBQVAsRUFBSixFQUFtQjtBQUNmLFVBQUl3QyxPQUFNM0QsU0FBU29DLE9BQVQsQ0FBaUI7QUFBQ1AsYUFBSVI7QUFBTCxPQUFqQixDQUFWO0FBQ0EsVUFBSXlGLFFBQUo7O0FBQ0EsVUFBR25ELElBQUgsRUFBUTtBQUNKbUQsbUJBQVNuRCxLQUFLNEMsU0FBZDtBQUNIOztBQUNELFVBQUlRLGlCQUFnQjlHLFVBQVVtQyxPQUFWLENBQWtCO0FBQUNvRSxpQkFBUUs7QUFBVCxPQUFsQixDQUFwQjtBQUNGLFVBQUlMLE9BQUo7O0FBQ0EsVUFBR00sUUFBSCxFQUFZO0FBQ1pOLGtCQUFRakcsT0FBT2UsTUFBUCxDQUFjO0FBQ3BCNkMsd0JBQWNBLFlBRE07QUFFcEJFLG1CQUFTNkIsS0FGVztBQUdwQjdFLGtCQUFRQSxNQUhZO0FBSXBCaUIseUJBQWV5RSxlQUFlekUsYUFBZixHQUE2QixDQUp4QjtBQUtwQm5CLGdCQUFNckIsT0FBT3FCLElBQVAsR0FBY1QsUUFMQTtBQU1wQnVFLHFCQUFXLElBQUlqQixJQUFKO0FBTlMsU0FBZCxDQUFSO0FBUUFoRSxpQkFBUzhCLE1BQVQsQ0FBZ0I7QUFBQ0QsZUFBSVIsTUFBTDtBQUFha0YscUJBQVU7QUFBdkIsU0FBaEIsRUFBNkM7QUFBQ3ZFLGdCQUFNO0FBQUNTLDBCQUFjO0FBQWY7QUFBUCxTQUE3QztBQUVBNUMsbUJBQVdpQyxNQUFYLENBQWtCO0FBQUNiLHFCQUFVSTtBQUFYLFNBQWxCLEVBQXFDO0FBQUNVLGdCQUFLO0FBQUNMLDJCQUFjO0FBQWY7QUFBTixTQUFyQyxFQUFrRTtBQUFDYyxpQkFBTTtBQUFQLFNBQWxFO0FBRUV2QyxrQkFBVXFCLE1BQVYsQ0FBaUI7QUFDakI2Qyx3QkFBY0EsWUFERztBQUVqQkUsbUJBQVM2QixLQUZRO0FBR2pCN0Usa0JBQVFBLE1BSFM7QUFJakJtRixtQkFBU0EsT0FKUTtBQUtqQmxFLHlCQUFleUUsZUFBZXpFLGFBQWYsR0FBNkIsQ0FMM0I7QUFNakJuQixnQkFBTXJCLE9BQU9xQixJQUFQLEdBQWNULFFBTkg7QUFPakJ1RSxxQkFBVyxJQUFJakIsSUFBSixFQVBNO0FBUWpCeUMsa0JBQVFNLGVBQWVsRjtBQVJOLFNBQWpCO0FBV0Q7QUFHRjtBQUNGO0FBcklZLENBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUEvQixPQUFPc0IsT0FBUCxDQUFlO0FBQ1gsaUJBQWUsVUFBU0ksTUFBVCxFQUFpQjtBQUM1QndGLFVBQU1DLGVBQU4sQ0FBc0J6RixNQUF0QixFQUE4QixDQUFDLE1BQUQsRUFBUSxXQUFSLENBQTlCLEVBRDRCLENBRTlCOztBQUNFeUIsWUFBUUMsR0FBUixDQUFZLDJCQUF5QjFCLE1BQXJDO0FBQ0g7QUFMVSxDQUFmLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIkJvb2tmb2xsb3cgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24oXCJib29rZm9sbG93XCIpOyIsIkJvb2tsaXN0ID0gbmV3IE1ldGVvci5Db2xsZWN0aW9uKFwiYm9va2xpc3RcIik7IiwiQnV0dGVyZmx5ID0gbmV3IE1ldGVvci5Db2xsZWN0aW9uKFwiYnV0dGVyZmx5XCIpOyIsIlJlbGF0aW9uc2hpcHMgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24oXCJyZWxhdGlvbnNoaXBzXCIpO1xyXG4iLCJDb21tZW50cyA9IG5ldyBNZXRlb3IuQ29sbGVjdGlvbihcImNvbW1lbnRzXCIpOyIsIk5vdGlmaWNhdGlvbnMgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24oXCJub3RpZmljYXRpb25zXCIpOyIsIlByb21wdHMgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24oXCJwcm9tcHRzXCIpOyIsIlJhdGluZ3MgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24oJ3JhdGluZ3MnKTsiLCJUd2VldHMgPSBuZXcgTWV0ZW9yLkNvbGxlY3Rpb24oXCJ0d2VldHNcIik7IiwiVXNlclV0aWxzID0gZnVuY3Rpb24oKSB7fTsgICAgLy9ubyB2YXIgaW4gZnJvbnRcclxuXHJcblVzZXJVdGlscy5maW5kRm9sbG93aW5ncyA9IGZ1bmN0aW9uKHVzZXJuYW1lKSB7ICBcclxuICB2YXIgY3VycmVudEZvbGxvd2luZ3MgPSBSZWxhdGlvbnNoaXBzLmZpbmQoe1xyXG4gICAgZm9sbG93ZXI6IHVzZXJuYW1lXHJcbiAgfSkuZmV0Y2goKS5tYXAoZnVuY3Rpb24oZGF0YSkge1xyXG4gICAgcmV0dXJuIGRhdGEuZm9sbG93aW5nO1xyXG4gIH0pO1xyXG4gIGN1cnJlbnRGb2xsb3dpbmdzLnB1c2goTWV0ZW9yLnVzZXIoKS51c2VybmFtZSk7XHJcblxyXG4gIHJldHVybiBjdXJyZW50Rm9sbG93aW5ncztcclxufTsiLCJNZXRlb3IubWV0aG9kcyh7ICBcclxuICAnZm9sbG93Qm9vayc6IGZ1bmN0aW9uKGJvb2tpZCkge1xyXG4gICAgQm9va2ZvbGxvdy5pbnNlcnQoe1xyXG4gICAgICBmb2xsb3dlcm5hbWU6IE1ldGVvci51c2VyKCkudXNlcm5hbWUsXHJcbiAgICAgIHVzZXJpZDogTWV0ZW9yLnVzZXJJZCgpLCAgICBcclxuICAgICAgZm9sbG93aW5nOiBib29raWQsXHJcbiAgICAgIHNhd25ld0NoYXB0ZXI6IHRydWUsXHJcbiAgICAgIGJvb2ttYXJrOjEsXHJcbiAgICB9KTtcclxuXHJcbiAgfSxcclxuICAndW5mb2xsb3dCb29rJzogZnVuY3Rpb24oYm9va2lkKXtcclxuICAgICAgQm9va2ZvbGxvdy5yZW1vdmUoe19pZDpib29raWR9KTtcclxuICAgICAgXHJcbiAgfSxcclxuICAnbWFya2FzTm90aWZpZWQnOiBmdW5jdGlvbihib29raWQpe1xyXG4gICAgICBCb29rZm9sbG93LnVwZGF0ZSh7XHJcbiAgICAgICAgIGZvbGxvd2VybmFtZTogTWV0ZW9yLnVzZXIoKS51c2VybmFtZSxcclxuICAgICAgICAgZm9sbG93aW5nOiBib29raWQsXHJcbiAgICAgICAgIHNhd25ld0NoYXB0ZXI6IGZhbHNlfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyRzZXQ6IHtzYXduZXdDaGFwdGVyOnRydWV9fSlcclxuICB9LFxyXG4gICdpbmNWaWV3TnVtYmVyJzogZnVuY3Rpb24oYm9va2lkKXtcclxuICAgICAgQm9va2xpc3QudXBkYXRlKHtfaWQ6IGJvb2tpZH0seyRpbmM6IHt2aWV3ZXJjb3VudDoxfX0pXHJcbiAgfSxcclxuICAncmVtb3ZlQ2hhcHRlcic6IGZ1bmN0aW9uKGNoYXB0ZXJpZCl7XHJcbiAgICAgIHZhciBjaGFwdGVyPSBUd2VldHMuZmluZE9uZSh7X2lkOmNoYXB0ZXJpZCx1c2VyOiBNZXRlb3IudXNlcigpLnVzZXJuYW1lfSk7XHJcbiAgICAgIGlmKGNoYXB0ZXIpe1xyXG4gICAgICAgIHZhciBkZWxjaGFwdGVybnVtYmVyPSBjaGFwdGVyLmNoYXB0ZXJudW1iZXI7XHJcbiAgICAgICAgVHdlZXRzLnVwZGF0ZSh7Ym9va2lkOmNoYXB0ZXIuYm9va2lkLHVzZXI6TWV0ZW9yLnVzZXIoKS51c2VybmFtZSxjaGFwdGVybnVtYmVyOnskZ3Q6ZGVsY2hhcHRlcm51bWJlcn19LHskaW5jOiB7Y2hhcHRlcm51bWJlcjogLTF9fSx7bXVsdGk6dHJ1ZX0pO1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBCb29rbGlzdC51cGRhdGUoe19pZDpjaGFwdGVyLmJvb2tpZH0seyRpbmM6IHtjaGFwdGVyY291bnQ6IC0xfX0pO1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBUd2VldHMucmVtb3ZlKHtfaWQ6Y2hhcHRlcmlkfSk7XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIFxyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gIH0sXHJcbiAgJ2RlbGV0ZUJvb2snOiBmdW5jdGlvbihib29raWQpe1xyXG4gICAgICBpZihCb29rbGlzdC5maW5kKHtfaWQ6Ym9va2lkLHVzZXI6TWV0ZW9yLnVzZXIoKS51c2VybmFtZX0pLmNvdW50KCk+MCl7XHJcbiAgICAgIEJvb2tmb2xsb3cucmVtb3ZlKHtmb2xsb3dpbmc6Ym9va2lkfSx7bXVsdGk6dHJ1ZX0pO1xyXG4gICAgICBUd2VldHMucmVtb3ZlKHtib29raWQ6Ym9va2lkfSx7bXVsdGk6dHJ1ZX0pO1xyXG4gICAgICBCb29rbGlzdC5yZW1vdmUoe19pZDpib29raWR9KTtcclxuICAgICAgICAgIFxyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gIH0sXHJcbiAgJ3JhdGVCb29rJzogZnVuY3Rpb24oYm9va2lkLHJhdGluZyl7XHJcbiAgICAgIGlmKFJhdGluZ3MuZmluZCh7Ym9va2lkOmJvb2tpZCx1c2VyOk1ldGVvci51c2VyKCkudXNlcm5hbWV9KS5jb3VudCgpPT0wKXtcclxuICAgICAgUmF0aW5ncy5pbnNlcnQoe2Jvb2tpZDogYm9va2lkLHVzZXI6IE1ldGVvci51c2VyKCkudXNlcm5hbWUscmF0aW5nOiByYXRpbmd9KTtcclxuICAgICAgdmFyIHJhdGluZ3M9IFJhdGluZ3MuZmluZCh7Ym9va2lkOmJvb2tpZH0pO1xyXG4gICAgICB2YXIgY291bnQ9IHJhdGluZ3MuY291bnQoKTtcclxuICAgICAgdmFyIHN1bSA9MDtcclxuICAgICAgICBfLmZvckVhY2gocmF0aW5ncy5mZXRjaCgpLGZ1bmN0aW9uKGl0ZW0pe1xyXG4gICAgICAgICBjb25zb2xlLmxvZyhpdGVtLnJhdGluZyk7XHJcbiAgICAgICAgIHN1bSs9cGFyc2VGbG9hdChpdGVtLnJhdGluZyk7XHJcbiAgICAgICAgfSkgO1xyXG4gICAgICAgICAgXHJcbiAgICAgIHZhciBhdmdyYXRpbmc9IHN1bS9jb3VudDtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiLS0tLS0tLS1cIik7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcInN1bTogXCIrc3VtKTtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiY291bnQ6IFwiK2NvdW50KTtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGF2Z3JhdGluZyk7XHJcbiAgICAgICAgICBcclxuICAgICAgdmFyIGF2Z3JvdW5kPU1hdGgucm91bmQoYXZncmF0aW5nKjIpLzI7ICAgICAgICBcclxuICAgICAgQm9va2xpc3QudXBkYXRlKHtfaWQ6Ym9va2lkfSx7JHNldDoge3JhdGluZzphdmdyb3VuZH19KTtcclxuICAgICAgXHJcbiAgICAgICAgICBcclxuICAgICAgfVxyXG4gICAgICBcclxuICB9LFxyXG4gICd1cGRhdGVCb29rVGl0bGUnOiBmdW5jdGlvbihib29raWQsdGl0bGUpe1xyXG4gICAgICBCb29rbGlzdC51cGRhdGUoe19pZDpib29raWQsdXNlcjpNZXRlb3IudXNlcigpLnVzZXJuYW1lfSx7JHNldDp7Ym9va3RpdGxlOnRpdGxlfX0pO1xyXG4gICAgICBcclxuICB9LFxyXG4gICd1cGRhdGVCb29rU3VtbWFyeSc6IGZ1bmN0aW9uKGJvb2tpZCxzdW1tYXJ5KXtcclxuICAgICAgQm9va2xpc3QudXBkYXRlKHtfaWQ6Ym9va2lkLHVzZXI6TWV0ZW9yLnVzZXIoKS51c2VybmFtZX0seyRzZXQ6e3N1bW1hcnk6c3VtbWFyeX19KTtcclxuICAgICAgXHJcbiAgfVxyXG59KTsiLCJNZXRlb3IubWV0aG9kcyh7ICBcclxuICAndXBkYXRlQm9va21hcmsnOiBmdW5jdGlvbihjaGFwdGVyaWQpIHtcclxuICAgICAgdmFyIGNoYXB0ZXJudW1iZXI7XHJcbiAgICAgIHZhciBib29rO1xyXG4gICAgICB2YXIgY2hhcHRlcj0gVHdlZXRzLmZpbmRPbmUoe19pZDpjaGFwdGVyaWR9KTtcclxuICAgICAgLy9jb25zb2xlLmxvZyhcIkJvb2ttYXJrIGZ1bmN0aW9uIGNhbGxlZFwiKTtcclxuICAgICAgaWYoY2hhcHRlciAmJiBNZXRlb3IudXNlci51c2VybmFtZSE9bnVsbCl7XHJcbiAgICAgICAgICAvL2NvbnNvbGUubG9nKGNoYXB0ZXIuY2hhcHRlcm51bWJlcik7XHJcbiAgICAgICAgICBjaGFwdGVybnVtYmVyPWNoYXB0ZXIuY2hhcHRlcm51bWJlcjtcclxuICAgICAgICAgIGJvb2s9Y2hhcHRlci5ib29raWQ7XHJcbiAgICAgICAgICB2YXIgdXNlcmZvbGxvdz0gQm9va2ZvbGxvdy5maW5kT25lKHtmb2xsb3dpbmc6Ym9vayxmb2xsb3dlcm5hbWU6TWV0ZW9yLnVzZXIoKS51c2VybmFtZX0pO1xyXG4gICAgICAgICAgaWYodXNlcmZvbGxvdyl7XHJcbiAgICAgICAgICB2YXIgYm9va21hcmtudW1iZXI9IHVzZXJmb2xsb3cuYm9va21hcmtcclxuICAgICAgICAgIGlmKGNoYXB0ZXJudW1iZXI+Ym9va21hcmtudW1iZXIpe1xyXG4gICAgICAgICAgIEJvb2tmb2xsb3cudXBkYXRlKHtmb2xsb3dpbmc6Ym9vayxmb2xsb3dlcm5hbWU6TWV0ZW9yLnVzZXIoKS51c2VybmFtZX0seyRzZXQ6e2Jvb2ttYXJrOiBjaGFwdGVybnVtYmVyfX0pOyBcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICB9LFxyXG4gICAgJ2FkZENvbW1lbnQnOiBmdW5jdGlvbihjaGFwdGVyaWQsIGNvbW1lbnQpe1xyXG4gICAgICAgIENvbW1lbnRzLmluc2VydCh7XHJcbiAgICAgICAgY2hhcHRlcmlkOiBjaGFwdGVyaWQsXHJcbiAgICAgICAgdXNlcjogTWV0ZW9yLnVzZXIoKS51c2VybmFtZSxcclxuICAgICAgICBjb21tZW50OiBjb21tZW50LFxyXG4gICAgICAgIHRpbWU6IG5ldyBEYXRlKClcclxuICAgICAgICB9KTtcclxuICAgICAgICBcclxuICAgICAgICBUd2VldHMudXBkYXRlKHtcclxuICAgICAgICBfaWQ6Y2hhcHRlcmlkfSx7JGluYzoge25ld2NvbW1lbnRzOiAxfX0gIFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG4gICAgJ0VkaXRDaGFwdGVyVGl0bGUnOiBmdW5jdGlvbihjaGFwdGVyaWQsIG5ld3RpdGxlKXtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImNoYW5naW5nIHRpdGxlXCIpO1xyXG4gICAgICAgIFR3ZWV0cy51cGRhdGUoe1xyXG4gICAgICAgIF9pZDogY2hhcHRlcmlkLFxyXG4gICAgICAgIHVzZXI6IE1ldGVvci51c2VyKCkudXNlcm5hbWVcclxuICAgICAgICB9LHskc2V0OntjaGFwdGVydGl0bGU6IG5ld3RpdGxlfX0pOyAgIFxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuICAgICdFZGl0Q2hhcHRlck1lc3NhZ2UnOiBmdW5jdGlvbihjaGFwdGVyaWQsIG5ld21lc3NhZ2Upe1xyXG4gICAgICAgIFR3ZWV0cy51cGRhdGUoe1xyXG4gICAgICAgIF9pZDogY2hhcHRlcmlkLFxyXG4gICAgICAgIHVzZXI6IE1ldGVvci51c2VyKCkudXNlcm5hbWVcclxuICAgICAgICB9LHskc2V0OnttZXNzYWdlOiBuZXdtZXNzYWdlfX0pOyAgIFxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuICAgICdFZGl0Q2hhcHRlclZpc2liaWxpdHknOiBmdW5jdGlvbihjaGFwdGVyaWQsIHZpc2liaWxpdHkpe1xyXG4gICAgICAgIFR3ZWV0cy51cGRhdGUoe1xyXG4gICAgICAgIF9pZDogY2hhcHRlcmlkLFxyXG4gICAgICAgIHVzZXI6IE1ldGVvci51c2VyKCkudXNlcm5hbWVcclxuICAgICAgICB9LHskc2V0Ont2aXNpYmlsaXR5OiB2aXNpYmlsaXR5fX0pOyAgIFxyXG4gICAgICAgIFxyXG4gICAgfVxyXG59KTsiLCJNZXRlb3IubWV0aG9kcyh7ICBcclxuICAnZmluZFVzZXInOiBmdW5jdGlvbih1c2VybmFtZSkge1xyXG4gICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kT25lKHtcclxuICAgICAgdXNlcm5hbWU6IHVzZXJuYW1lXHJcbiAgICB9LCB7XHJcbiAgICAgIGZpZWxkczogeyAndXNlcm5hbWUnOiAxIH1cclxuICAgIH0pO1xyXG4gIH1cclxufSk7XHJcblxyXG5cclxuTWV0ZW9yLm1ldGhvZHMoeyAgXHJcbiAgJ2ZpbmRVc2Vycyc6IGZ1bmN0aW9uKHVzZXJuYW1lKSB7XHJcbiAgICByZXR1cm4gQm9va2xpc3QuZmluZCh7XHJcbiAgICAgIGJvb2t0aXRsZTpuZXcgUmVnRXhwKHVzZXJuYW1lLFwiaVwiKVxyXG4gICAgfSwge1xyXG4gICAgICBmaWVsZHM6IHsgJ2Jvb2t0aXRsZSc6IDEsIGJvb2tpZDogMSwgY292ZXI6MSwgdXNlcjoxICB9XHJcbiAgICB9KS5mZXRjaCgpO1xyXG4gIH1cclxufSk7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7ICBcclxuICAnZmluZFVzZXJjb3VudCc6IGZ1bmN0aW9uKHVzZXJuYW1lKSB7XHJcbiAgICByZXR1cm4gQm9va2xpc3QuZmluZCh7XHJcbiAgICAgIGJvb2t0aXRsZTogbmV3IFJlZ0V4cCh1c2VybmFtZSl9LCB7XHJcbiAgICAgIGZpZWxkczogeyAnYm9va3RpdGxlJzogMSAsIGJvb2tpZDogMX1cclxuICAgIH0pLmNvdW50KCk7XHJcbiAgfVxyXG59KTtcclxuXHJcbk1ldGVvci5tZXRob2RzKHsgIFxyXG4gICdmb2xsb3dVc2VyJzogZnVuY3Rpb24odXNlcm5hbWUpIHtcclxuICAgIFJlbGF0aW9uc2hpcHMuaW5zZXJ0KHtcclxuICAgICAgZm9sbG93ZXI6IE1ldGVvci51c2VyKCkudXNlcm5hbWUsXHJcbiAgICAgIGZvbGxvd2luZzogdXNlcm5hbWVcclxuICAgIH0pO1xyXG4gIH1cclxufSk7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7ICBcclxuICAncmVjb21tZW5kVXNlcnMnOiBmdW5jdGlvbigpIHtcclxuICAgIGlmIChNZXRlb3IudXNlcigpKSB7XHJcbiAgICAgIHZhciBjdXJyZW50Rm9sbG93aW5ncyA9IFVzZXJVdGlscy5maW5kRm9sbG93aW5ncyhNZXRlb3IudXNlcigpLnVzZXJuYW1lKTtcclxuXHJcbiAgICAgIHZhciByZWNVc2VycyA9IE1ldGVvci51c2Vycy5maW5kKHtcclxuICAgICAgICB1c2VybmFtZToge1xyXG4gICAgICAgICAgJG5pbjogY3VycmVudEZvbGxvd2luZ3NcclxuICAgICAgICB9XHJcbiAgICAgIH0sIHtcclxuICAgICAgICBmaWVsZHM6IHsgJ3VzZXJuYW1lJzogMSB9LFxyXG4gICAgICAgIGxpbWl0OiA1XHJcbiAgICAgIH0pLmZldGNoKCk7XHJcblxyXG4gICAgICByZXR1cm4gcmVjVXNlcnM7XHJcbiAgICB9XHJcbiAgfVxyXG59KTsiLCJNZXRlb3IubWV0aG9kcyh7XHJcbiAgaW5zZXJ0UHJvbXB0OiBmdW5jdGlvbihzdW1tYXJ5LGdlbnJlcykge1xyXG4gICAgaWYgKE1ldGVvci51c2VyKCkpIHtcclxuICAgICAgICBQcm9tcHRzLmluc2VydCh7XHJcbiAgICAgICAgICAgIHN1bW1hcnk6IHN1bW1hcnksXHJcbiAgICAgICAgICAgIGdlbnJlOiBnZW5yZXMsXHJcbiAgICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKSxcclxuICAgICAgICAgICAgdXNlcjogTWV0ZW9yLnVzZXIoKS51c2VybmFtZSAgXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgfVxyXG4gICAgXHJcbn0pOyIsIk1ldGVvci5wdWJsaXNoQ29tcG9zaXRlKCd0d2VldHMnLCBmdW5jdGlvbih1c2VybmFtZSkge1xyXG4gIHJldHVybiB7XHJcbiAgICBmaW5kOiBmdW5jdGlvbigpIHtcclxuICAgICAgLy8gRmluZCB0aGUgY3VycmVudCB1c2VyJ3MgZm9sbG93aW5nIHVzZXJzXHJcbiAgICAgIHJldHVybiBSZWxhdGlvbnNoaXBzLmZpbmQoeyBmb2xsb3dlcjogdXNlcm5hbWUgfSk7XHJcbiAgICB9LFxyXG4gICAgY2hpbGRyZW46IFt7XHJcbiAgICAgIGZpbmQ6IGZ1bmN0aW9uKHJlbGF0aW9uc2hpcCkge1xyXG4gICAgICAgIC8vIEZpbmQgdHdlZXRzIGZyb20gZm9sbG93ZWQgdXNlcnNcclxuICAgICAgICByZXR1cm4gVHdlZXRzLmZpbmQoe3VzZXI6IHJlbGF0aW9uc2hpcC5mb2xsb3dpbmd9KTtcclxuICAgICAgfVxyXG4gICAgfV1cclxuICB9XHJcbn0pO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ293blR3ZWV0cycsIGZ1bmN0aW9uKHVzZXJuYW1lKSB7XHJcbiAgcmV0dXJuIFR3ZWV0cy5maW5kKHt1c2VyOiB1c2VybmFtZX0pO1xyXG59KTtcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdmb2xsb3dpbmdCb29rcycsIGZ1bmN0aW9uKHVzZXJuYW1lKSB7XHJcbiAgcmV0dXJuIEJvb2tmb2xsb3cuZmluZCh7Zm9sbG93ZXJuYW1lOiB1c2VybmFtZX0pO1xyXG59KTtcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdvd25Cb29rcycsIGZ1bmN0aW9uKHVzZXJuYW1lKSB7XHJcbiAgcmV0dXJuIEJvb2tsaXN0LmZpbmQoe3VzZXI6IHVzZXJuYW1lfSk7XHJcbn0pO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ2hpZGRlblR3ZWV0cycsIGZ1bmN0aW9uKHVzZXJuYW1lKSB7XHJcbiAgcmV0dXJuIFR3ZWV0cy5maW5kKHt1c2VyOiB1c2VybmFtZSwgdmlzaWJpbGl0eTogXCJVbmxpc3RlZFwifSk7XHJcbn0pO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ0Jvb2tzJywgZnVuY3Rpb24oKSB7XHJcbiAgcmV0dXJuIEJvb2tsaXN0LmZpbmQoe30pO1xyXG59KTtcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdQcm9tcHRzJywgZnVuY3Rpb24oKSB7XHJcbiAgcmV0dXJuIFByb21wdHMuZmluZCh7fSk7XHJcbn0pO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ1R3ZWV0cycsIGZ1bmN0aW9uKCkge1xyXG4gIHJldHVybiBUd2VldHMuZmluZCh7dmlzaWJpbGl0eTpcIlB1YmxpY1wifSk7XHJcbn0pO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ2Jvb2tDaGFwdGVycycsIGZ1bmN0aW9uKGlkKSB7XHJcbiAgcmV0dXJuIFR3ZWV0cy5maW5kKHtfaWQ6IGlkfSk7XHJcbn0pO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ2Jvb2tDaGFwdGVyc0FsbCcsIGZ1bmN0aW9uKGlkKSB7XHJcbiAgcmV0dXJuIFR3ZWV0cy5maW5kKHt9KTtcclxufSk7XHJcblxyXG5NZXRlb3IucHVibGlzaCgnVXNlclByb2ZpbGUnLCBmdW5jdGlvbihpZCkge1xyXG4gIHJldHVybiBVc2VyLmZpbmQoe30pO1xyXG59KTtcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdSYXRpbmdzJywgZnVuY3Rpb24oaWQpIHtcclxuICByZXR1cm4gUmF0aW5ncy5maW5kKHt9KTtcclxufSk7XHJcblxyXG5NZXRlb3IucHVibGlzaCgnQ29tbWVudHMnLCBmdW5jdGlvbihpZCkge1xyXG4gIHJldHVybiBDb21tZW50cy5maW5kKHt9KTtcclxufSk7XHJcblxyXG5NZXRlb3IucHVibGlzaCgndXNlcnMnLCBmdW5jdGlvbih1c2VybmFtZSkge1xyXG4gIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7dXNlcm5hbWU6IHVzZXJuYW1lfSwge1xyXG4gICAgZmllbGRzOiB7IHByb2ZpbGU6dHJ1ZSB9LFxyXG4gICAgbGltaXQ6IDEwMFxyXG4gIH0pO1xyXG59KTtcclxuXHJcblxyXG4gIE1ldGVvci5wdWJsaXNoKCdCdXR0ZXJmbHknLCBmdW5jdGlvbiAoKSB7XHJcbiAgICByZXR1cm4gQnV0dGVyZmx5LmZpbmQoe30pO1xyXG4gIH0pO1xyXG5cclxuXHJcblxyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ2Jvb2tmb2xsb3cnLCBmdW5jdGlvbigpIHtcclxuICByZXR1cm4gQm9va2ZvbGxvdy5maW5kKHt9KTtcclxufSk7XHJcblxyXG5NZXRlb3IucHVibGlzaCgnZm9sbG93aW5ncycsIGZ1bmN0aW9uKHVzZXJuYW1lKSB7XHJcbiAgcmV0dXJuIFJlbGF0aW9uc2hpcHMuZmluZCh7IGZvbGxvd2VyOiB1c2VybmFtZSB9KTtcclxufSk7XHJcblxyXG5NZXRlb3IucHVibGlzaCgnZm9sbG93ZXJzJywgZnVuY3Rpb24odXNlcm5hbWUpIHtcclxuICByZXR1cm4gUmVsYXRpb25zaGlwcy5maW5kKHsgZm9sbG93aW5nOiB1c2VybmFtZSB9KTtcclxufSk7XHJcblxyXG5cclxuXHJcbkhvdXN0b24uYWRkX2NvbGxlY3Rpb24oTWV0ZW9yLnVzZXJzKTtcclxuXHJcblxyXG4iLCJNZXRlb3Iuc3RhcnR1cChmdW5jdGlvbiAoKSB7IFxyXG4gICAgXHJcblxyXG4gIFJlbGF0aW9uc2hpcHMuX2Vuc3VyZUluZGV4KHtmb2xsb3dlcjogMSwgZm9sbG93aW5nOiAxfSwge3VuaXF1ZTogMX0pO1xyXG5cclxuQWNjb3VudHMub25DcmVhdGVVc2VyKGZ1bmN0aW9uIChvcHRpb25zLCB1c2VyKSB7XHJcbiAgICBcclxuXHJcbiAgICBpZiAob3B0aW9ucy5wcm9maWxlKSB7XHJcbiAgICAgIC8vIGluY2x1ZGUgdGhlIHVzZXIgcHJvZmlsZVxyXG4gICAgICB1c2VyLnByb2ZpbGUgPSBvcHRpb25zLnByb2ZpbGVcclxuICAgICAgXHJcbiAgICB9XHJcblxyXG4gICAgLy8gb3RoZXIgdXNlciBvYmplY3QgY2hhbmdlcy4uLlxyXG4gICAgLy8gLi4uXHJcbiAgICBcclxuICAgIHJldHVybiB1c2VyO1xyXG4gIH0pO1xyXG5cclxuXHJcblxyXG5cclxufSk7IiwiTWV0ZW9yLm1ldGhvZHMoe1xyXG4gIGluc2VydFR3ZWV0OiBmdW5jdGlvbih0d2VldCx0aXRsZSxjaGFwdGVydGl0bGUsdmlzaWJpbGl0eSkge1xyXG4gICAgaWYgKE1ldGVvci51c2VyKCkpIHtcclxuICAgICAgICB2YXIgYm9vaz0gQm9va2xpc3QuZmluZE9uZSh7Ym9va3RpdGxlOnRpdGxlLHVzZXI6TWV0ZW9yLnVzZXIoKS51c2VybmFtZX0pO1xyXG4gICAgICAgIHZhciBib29raWQ7XHJcbiAgICAgICAgaWYoYm9vayl7XHJcbiAgICAgICAgICAgIGJvb2tpZD1ib29rLl9pZDtcclxuICAgICAgICB9XHJcbiAgICAgIGlmKGJvb2tpZCl7ICBcclxuICAgICAgVHdlZXRzLmluc2VydCh7XHJcbiAgICAgICAgY2hhcHRlcnRpdGxlOiBjaGFwdGVydGl0bGUsXHJcbiAgICAgICAgbWVzc2FnZTogdHdlZXQsXHJcbiAgICAgICAgYm9va2lkOiBib29raWQsXHJcbiAgICAgICAgY2hhcHRlcm51bWJlcjogYm9vay5jaGFwdGVyY291bnQrMSwgIFxyXG4gICAgICAgIHVzZXI6IE1ldGVvci51c2VyKCkudXNlcm5hbWUsXHJcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgIHZpc2liaWxpdHk6dmlzaWJpbGl0eVxyXG4gICAgICB9KTtcclxuICAgICAgQm9va2xpc3QudXBkYXRlKHtib29rdGl0bGU6dGl0bGUsIHVzZXI6IE1ldGVvci51c2VyKCkudXNlcm5hbWV9LHskaW5jOiB7Y2hhcHRlcmNvdW50OiAxfX0pO1xyXG4gICAgICBcclxuICAgICAgQm9va2ZvbGxvdy51cGRhdGUoe2ZvbGxvd2luZzpib29raWR9LHskc2V0OntzYXduZXdDaGFwdGVyOmZhbHNlfX0se211bHRpOnRydWV9KTsgICAgICAgIFxyXG4gICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICB9XHJcbiAgfSxcclxuICBcclxuICBpbnNlcnRCb29rOiBmdW5jdGlvbih0aXRsZSxjb3Zlcix0d2VldCxjaGFwdGVydGl0bGUsIGJ1dHRlciwgYm9va3N1bW1hcnksZ2VucmVzLHByb21wdCkge1xyXG4gICAgaWYgKE1ldGVvci51c2VyKCkpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyh0aXRsZSsgXCIgIFwiKyBib29rc3VtbWFyeSk7XHJcbiAgICAgICAgaWYoYm9va3N1bW1hcnkgPT0gXCJcIil7XHJcbiAgICAgICAgIGJvb2tzdW1tYXJ5ID0gXCJObyBzdW1tYXJ5IGZvciB0aGlzIGJvb2sgYXZhaWxhYmxlXCI7ICAgXHJcbiAgICAgICAgfVxyXG4gICAgICBCb29rbGlzdC5pbnNlcnQoe1xyXG4gICAgICAgIGJvb2t0aXRsZTogdGl0bGUsXHJcbiAgICAgICAgY292ZXI6IGNvdmVyLFxyXG4gICAgICAgIGNoYXB0ZXJjb3VudDogMSxcclxuICAgICAgICB1c2VyOiBNZXRlb3IudXNlcigpLnVzZXJuYW1lLFxyXG4gICAgICAgIHZpZXdlcmNvdW50OjEsICBcclxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCksXHJcbiAgICAgICAgYnV0dGVyZmx5OmJ1dHRlcixcclxuICAgICAgICAgIHN1bW1hcnk6IGJvb2tzdW1tYXJ5LFxyXG4gICAgICAgICAgZ2VucmVzOiBnZW5yZXMsXHJcbiAgICAgICAgICBwcm9tcHQ6cHJvbXB0XHJcbiAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBib29rPSBCb29rbGlzdC5maW5kT25lKHtib29rdGl0bGU6dGl0bGUsY292ZXI6Y292ZXIsdXNlcjpNZXRlb3IudXNlcigpLnVzZXJuYW1lfSk7XHJcbiAgICAgICAgdmFyIGJvb2tpZDtcclxuICAgICAgICBpZihib29rKXtcclxuICAgICAgICAgICAgYm9va2lkPWJvb2suX2lkO1xyXG4gICAgICAgIH1cclxuICAgICAgICB2YXIgdHdlZXRpZDtcclxuICAgICAgICBpZihib29raWQpe1xyXG4gICAgICAgIHR3ZWV0aWQ9ICAgVHdlZXRzLmluc2VydCh7XHJcbiAgICAgICAgY2hhcHRlcnRpdGxlOiBjaGFwdGVydGl0bGUsXHJcbiAgICAgICAgbWVzc2FnZTogdHdlZXQsXHJcbiAgICAgICAgYm9va2lkOiBib29raWQsXHJcbiAgICAgICAgY2hhcHRlcm51bWJlcjogMSwgIFxyXG4gICAgICAgIHVzZXI6IE1ldGVvci51c2VyKCkudXNlcm5hbWUsXHJcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpXHJcbiAgICAgICAgICAgfSk7IFxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBpZihidXR0ZXIpe1xyXG4gICAgICAgICAgIEJ1dHRlcmZseS5pbnNlcnQoe1xyXG4gICAgICAgIGNoYXB0ZXJ0aXRsZTogdGl0bGUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJcIixcclxuICAgICAgICBib29raWQ6IGJvb2tpZCxcclxuICAgICAgICBjaGFwdGVybnVtYmVyOiAwLCAgXHJcbiAgICAgICAgdXNlcjogTWV0ZW9yLnVzZXIoKS51c2VybmFtZSxcclxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCksXHJcbiAgICAgICAgcGFyZW50OiBudWxsXHJcbiAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHZhciBib29rYnV0dGVyO1xyXG4gICAgICAgICAgICBpZihib29raWQpe1xyXG4gICAgICAgIGJvb2tidXR0ZXI9QnV0dGVyZmx5LmZpbmRPbmUoe2Jvb2tpZDogYm9va2lkLCBjaGFwdGVybnVtYmVyOjB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGJ1dHRlcmlkO1xyXG4gICAgICAgIGlmKGJvb2tidXR0ZXIpe1xyXG4gICAgICAgICAgICBidXR0ZXJpZD1ib29rYnV0dGVyLl9pZDtcclxuICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBCdXR0ZXJmbHkuaW5zZXJ0KHtcclxuICAgICAgICBjaGFwdGVydGl0bGU6IGNoYXB0ZXJ0aXRsZSxcclxuICAgICAgICBtZXNzYWdlOiB0d2VldCxcclxuICAgICAgICBib29raWQ6IGJvb2tpZCxcclxuICAgICAgICB0d2VldGlkOiB0d2VldGlkLFxyXG4gICAgICAgIGNoYXB0ZXJudW1iZXI6IDEsICBcclxuICAgICAgICB1c2VyOiBNZXRlb3IudXNlcigpLnVzZXJuYW1lLFxyXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKSxcclxuICAgICAgICBwYXJlbnQ6IGJ1dHRlcmlkXHJcbiAgICAgICAgICAgfSk7IFxyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgfSxcclxuICBpbnNlcnRCdXR0ZXJmbHk6IGZ1bmN0aW9uKHR3ZWV0LGNoYXB0ZXJ0aXRsZSxib29raWQsY3VycmVudGlkKSB7XHJcbiAgICBpZiAoTWV0ZW9yLnVzZXIoKSkge1xyXG4gICAgICAgIHZhciBib29rPSBCb29rbGlzdC5maW5kT25lKHtfaWQ6Ym9va2lkfSk7XHJcbiAgICAgICAgdmFyIGlzYnV0dGVyO1xyXG4gICAgICAgIGlmKGJvb2spe1xyXG4gICAgICAgICAgICBpc2J1dHRlcj1ib29rLmJ1dHRlcmZseTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdmFyIGN1cnJlbnRjaGFwdGVyPSBCdXR0ZXJmbHkuZmluZE9uZSh7dHdlZXRpZDpjdXJyZW50aWR9KTtcclxuICAgICAgdmFyIHR3ZWV0aWQ7XHJcbiAgICAgIGlmKGlzYnV0dGVyKXsgIFxyXG4gICAgICB0d2VldGlkPVR3ZWV0cy5pbnNlcnQoe1xyXG4gICAgICAgIGNoYXB0ZXJ0aXRsZTogY2hhcHRlcnRpdGxlLFxyXG4gICAgICAgIG1lc3NhZ2U6IHR3ZWV0LFxyXG4gICAgICAgIGJvb2tpZDogYm9va2lkLFxyXG4gICAgICAgIGNoYXB0ZXJudW1iZXI6IGN1cnJlbnRjaGFwdGVyLmNoYXB0ZXJudW1iZXIrMSwgIFxyXG4gICAgICAgIHVzZXI6IE1ldGVvci51c2VyKCkudXNlcm5hbWUsXHJcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpXHJcbiAgICAgIH0pO1xyXG4gICAgICBCb29rbGlzdC51cGRhdGUoe19pZDpib29raWQsIGJ1dHRlcmZseTp0cnVlfSx7JGluYzoge2NoYXB0ZXJjb3VudDogMX19KTtcclxuICAgICAgXHJcbiAgICAgIEJvb2tmb2xsb3cudXBkYXRlKHtmb2xsb3dpbmc6Ym9va2lkfSx7JHNldDp7c2F3bmV3Q2hhcHRlcjpmYWxzZX19LHttdWx0aTp0cnVlfSk7ICAgICAgICBcclxuICAgICAgXHJcbiAgICAgICAgQnV0dGVyZmx5Lmluc2VydCh7XHJcbiAgICAgICAgY2hhcHRlcnRpdGxlOiBjaGFwdGVydGl0bGUsXHJcbiAgICAgICAgbWVzc2FnZTogdHdlZXQsXHJcbiAgICAgICAgYm9va2lkOiBib29raWQsXHJcbiAgICAgICAgdHdlZXRpZDogdHdlZXRpZCxcclxuICAgICAgICBjaGFwdGVybnVtYmVyOiBjdXJyZW50Y2hhcHRlci5jaGFwdGVybnVtYmVyKzEsICBcclxuICAgICAgICB1c2VyOiBNZXRlb3IudXNlcigpLnVzZXJuYW1lLFxyXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKSxcclxuICAgICAgICBwYXJlbnQ6IGN1cnJlbnRjaGFwdGVyLl9pZFxyXG4gICAgICAgICAgIH0pOyBcclxuICAgICAgXHJcbiAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgIH1cclxuICB9XHJcbiAgICBcclxufSk7IiwiTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgJ3NldFVzZXJSb2xlJzogZnVuY3Rpb24odXNlcmlkKSB7XHJcbiAgICAgICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKHVzZXJpZCwgWyd1c2VyJywnY2FuLXdyaXRlJ10pO1xyXG4gICAgICAvLyAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKFwic21aYzdzTldFSGRrUEtFNHdcIiwgWydhZG1pbicsJ3VzZXInLCdjYW4td3JpdGUnXSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJTZXR0aW5nIHVzZXIgcm9sZSBmb3IgXCIrdXNlcmlkKTtcclxuICAgIH1cclxuXHJcblxyXG59KTsiXX0=
